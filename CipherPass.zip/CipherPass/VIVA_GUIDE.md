# Pakistan Bank KYC System — Viva Preparation Guide

## Quick Answers for Teacher Questions

### Q1: "What is this project about?"
**Answer:**
"This project demonstrates **Know Your Customer (KYC)** verification used by Pakistani banks when opening accounts. It combines Digital Image Processing (DIP) for document enhancement with criminal record checking (AML compliance) and FIA watchlist screening. When someone opens a bank account, the teller uploads their CNIC, captures face, checks if the person is on the criminal/fraud list, detects if the person has been verified multiple times before (duplicate fraud), then approves or rejects the account."

---

### Q2: "Where is this used in real life?"
**Answer:**
"All Pakistani banks use this:
- **HBL, UBL, Meezan, Allied Bank** — Account opening at branch
- **JazzCash, Easypaisa** — Mobile wallet signup
- **NADRA** — National ID verification
- **Microfinance banks** — Loan applications
- **FIA** — Federal Investigation Agency criminal screening

It is a legal requirement under AML (Anti-Money Laundering) compliance. Banks must verify identity and check the FIA criminal watchlist before opening accounts."

---

### Q3: "What DIP techniques are used and why?"
**Answer:**

| Technique | Used For | Real-World Purpose |
|-----------|----------|-------------------|
| **Grayscale** | Color standardization | Process all images the same way |
| **Histogram Equalization** | Enhance brightness | Brighten faded CNIC cards |
| **Gaussian Blur** | Remove noise | Clean poor phone camera images |
| **Canny Edge Detection** | Find document boundaries | Detect CNIC corners for cropping |
| **CLAHE** | Local contrast enhancement | Make small CNIC text sharp |
| **Laplacian** | Measure sharpness | Detect blurry images (liveness check) |
| **Haar Cascade** | Face detection | Real-time webcam face capture |

"We use these because customers give poor-quality photos taken with old phones in low light. DIP techniques enhance them so the CNIC can be read and verified accurately."

---

### Q4: "How does the liveness check work?"
**Answer:**
"We use the **Laplacian operator** to detect if the image is sharp or blurry:
- High Laplacian variance = sharp image = real person in front of camera
- Low variance = blurry image = might be a printed photo being held up

This prevents spoofing where someone holds a printed photo to the camera instead of their real face."

**Code location:** `face_module.py`

---

### Q5: "How does criminal record search prevent fraud?"
**Answer:**
"The system searches `criminal_records.json` which simulates the FIA (Federal Investigation Agency) criminal watchlist:

1. **High-risk** → AUTO-REJECT
   - Convicted identity fraudsters
   - Money launderers
   - Sanctions violators
   - Cybercriminals

2. **Medium-risk** → MANUAL REVIEW
   - Loan defaulters
   - Cheque bouncers

3. **Clean** → APPROVE

**When a criminal CNIC is entered, a warning popup appears BEFORE full verification starts.** This is by design — the system alerts the teller immediately."

**Test:** Enter CNIC `12345-6789012-3` to see criminal record (identity fraud + document forgery)

---

### Q6: "What is the DUPLICATE detection feature?"
**Answer:**
"If the same CNIC is verified 3 or more times in the system, it triggers a **DUPLICATE FRAUD ALERT**:

- A popup warning appears before verification starts
- The right panel shows: 'DUPLICATE ALERT — N previous verifications found'
- This detects account takeover attempts where a fraudster keeps trying the same CNIC

**Code:** `customer_screening.py` — `get_previous_verifications()` + `screening_decision()` with `previous_count >= 3`"

---

### Q7: "What is REPORT_FIA?"
**Answer:**
"REPORT_FIA stands for **Report to Federal Investigation Agency**. It is one of the compliance officer actions in the Compliance Review Dialog that appears after a criminal record is detected.

The compliance officer can choose:
- **REJECT** — Block account opening immediately
- **ESCALATE** — Send to branch manager
- **INVESTIGATE** — Request more documents
- **REPORT_FIA** — Formally report the person to FIA for criminal investigation
- **HOLD** — Pending further review

In real Pakistani banking, the FIA handles cases of identity fraud, money laundering, and financial crimes. Selecting REPORT_FIA records the officer's name, timestamp, and notes — saved to `verification_data/compliance_decisions.json`."

---

### Q8: "How is trust score calculated?"
**Answer:**
"Trust score uses a weighted formula combining 3 factors:

```
Trust = (Face Score × 0.40) + (Document Score × 0.35) + (Signature × 0.25)
```

Then penalties are applied:
- **Criminal record found**: -40 points
- **REJECT decision**: -25 points
- **Name does not match bank record**: -35 points

**Decision thresholds:**
- Score >= 70 → LOW RISK — Proceed
- Score 45–69 → MEDIUM — Manual review
- Score < 45 → HIGH RISK — Blocked"

**Code:** `scoring.py`

---

### Q9: "Show me how the system works step-by-step"
**Answer:**

**Step 1:** Upload CNIC front — DIP enhancement applied automatically

**Step 2:** Enter customer data (CNIC number, name, father name, DOB, address)

**Step 3:** Click 'Lookup customer profile' — instantly shows criminal record and bank status

**Step 4:** Capture face via camera — Haar Cascade detects face with green bounding box

**Step 5:** Click START VERIFICATION:
- Module 1: Input received
- Module 2: DIP applied (grayscale, blur, Canny)
- Module 3: Document checked
- Module 4: Bank DB + FIA criminal database checked, duplicate count checked
- Module 5: Trust score calculated

**Step 6:** If criminal record found — Compliance Review Dialog opens for officer action

---

### Q10: "What are the test CNICs and expected results?"

```
CLEAN CUSTOMERS (APPROVE):
  42101-1234567-1 — Ahmed Raza — No criminal record — APPROVE

CRIMINALS (AUTO-REJECT):
  12345-6789012-3 — Identity Fraud + Document Forgery
  11111-2222222-3 — Bank Fraud + Money Laundering
  33201-7777777-7 — SIM Fraud + Cybercrime
  44401-8888888-8 — ATM Card Cloning
  43301-1212121-3 — International Sanctions Violation
  All above: show criminal warning popup + compliance review

MANUAL REVIEW:
  54321-0987654-1 — Sara Malik — Signature Forgery
  41101-5555555-5 — Loan Default + Cheque Bounce

DUPLICATE TEST:
  Verify any CNIC 3+ times — triggers DUPLICATE FRAUD ALERT popup
```

---

### Q11: "Where is data stored?"

```
citizen_database.json                         — Bank customer records
criminal_records.json                         — FIA/AML criminal watchlist
verification_data/history.json                — All KYC session records
verification_data/compliance_decisions.json   — Officer decisions (REPORT_FIA etc.)
verification_data/cnic_archive/<CNIC>/        — Per-person CNIC images + metadata
```

---

### Q12: "What databases are used?"

1. **citizen_database.json** — Bank customer records (name, CNIC, address, trust score)
2. **criminal_records.json** — FIA/AML watchlist (crimes, dates, penalties, risk level, flags)
3. **verification_data/history.json** — Previous KYC checks, used for duplicate detection

---

## Quick Demo for Teacher (5 Minutes)

1. **Show GUI** (30 sec) — "This is Pakistan banking KYC terminal"

2. **Criminal Lookup** (1 min)
   - Enter CNIC: `12345-6789012-3`
   - Click "Lookup customer profile"
   - Show: Criminal record found — Identity Fraud + Document Forgery

3. **Upload CNIC + DIP Steps** (1 min)
   - Click "Upload Front" — any image
   - Click "Show DIP Processing Steps"
   - Point out: Grayscale → Histogram → Blur → Edges → CLAHE

4. **Full Verification with Criminal** (1.5 min)
   - Keep CNIC `12345-6789012-3`
   - Capture face → START VERIFICATION
   - Show: Criminal warning popup before verification
   - After result: Compliance Review Dialog opens
   - Select REPORT_FIA → Enter officer name → Save Decision

5. **Explain Industry Use** (1 min)
   - "Banks use this for KYC — must check FIA criminal database for AML compliance"
   - "DIP improves poor-quality photos from old phones"
   - "REPORT_FIA reports confirmed criminals to Federal Investigation Agency"

---

## Key Files to Know

| File | What to Show |
|------|-------------|
| `main.py` | Main GUI and 5-module verification flow |
| `customer_screening.py` | Criminal lookup + duplicate detection logic |
| `criminal_records.json` | FIA watchlist — open and show CNIC `12345-6789012-3` |
| `dip_pipeline.py` | 6-step DIP enhancement |
| `scoring.py` | Trust score formula |

---

## Common Teacher Questions

**Q: "Why warn before verification if criminal record found?"**
A: "In real banking, tellers need to know immediately if a person is on the FIA watchlist — before spending time on full verification. The pre-check saves branch time and alerts the teller to be cautious."

**Q: "How does duplicate detection work?"**
A: "Every verification is saved in history.json. On new verification, we count how many times this CNIC was checked before. Three or more previous checks triggers a DUPLICATE ALERT — this matches real bank fraud patterns where an attacker repeatedly tries the same stolen CNIC."

**Q: "Can this be used in production?"**
A: "No, this is educational. Real banks connect to actual government databases, use DeepFace for recognition, and process millions of transactions daily. This project teaches the concepts and workflow."

---

Good luck with your viva!
