# CipherPass — Encrypted Identity Clearance & Intelligence Platform

## Project Overview

**CipherPass** is a professional desktop application built for Pakistani banking institutions to perform KYC (Know Your Customer) and AML (Anti-Money Laundering) compliance checks at the counter. It combines computer vision, digital image processing, biometric verification, and criminal intelligence screening into a single operator-facing interface.

**Course**: Digital Image Processing (DIP)  
**Technology**: Python 3.11 · PyQt5 · OpenCV 4 · NumPy · ReportLab  
**Platform**: Windows / Linux desktop  
**Theme**: Premium dark purple professional UI

---

## Quick Start

### Run the Application
```bash
pip install -r requirements.txt
python main.py
```

### Demo Test CNICs

| CNIC | Name | Expected Outcome |
|------|------|-----------------|
| 42101-1234567-1 | Ahmed Raza | APPROVED — clean record, score ~87 |
| 12345-6789012-3 | Hassan Ali | REJECTED — criminal record (Identity Fraud) |
| 11111-2222222-3 | Bilal Khan | REJECTED — Bank Fraud + Money Laundering |
| 33201-7777777-7 | Zubair Hassan | REJECTED — SIM Fraud + Cybercrime |

Verify any CNIC 3+ times to trigger the **Duplicate Fraud Alert**.

---

## Project Architecture (5-Module Design)

```
┌─────────────────────────────────────────────────────────────┐
│                        CipherPass                            │
├──────────────┬──────────────┬──────────────┬────────────────┤
│   INPUT      │  DIP ENGINE  │   BIOMETRIC  │  INTELLIGENCE  │
│              │              │              │                │
│ CNIC Upload  │ 17-Step      │ Haar Cascade │ AML Watchlist  │
│ Face Capture │ Pipeline     │ Face Match   │ Criminal DB    │
│ Manual Entry │ 5 Categories │ Liveness     │ Duplicate Det. │
└──────────────┴──────────────┴──────────────┴────────────────┘
                              │
                    ┌─────────▼─────────┐
                    │   TRUST SCORING   │
                    │ Face×0.40         │
                    │ Document×0.35     │
                    │ Signature×0.25    │
                    │                   │
                    │  ≥70 → APPROVE    │
                    │  45–69 → REVIEW   │
                    │  <45  → REJECT    │
                    └───────────────────┘
```

---

## File Structure

```
CipherPass/
├── main.py                  ← Main PyQt5 GUI window + all dialogs
├── ui_styles.py             ← Global dark-purple theme stylesheet
├── dip_pipeline.py          ← 17-step DIP processing pipeline
├── dip_concepts.py          ← All DIP algorithm implementations
├── dip_showcase_dialog.py   ← Interactive DIP concept viewer
├── face_module.py           ← Face detection + liveness check
├── document_module.py       ← CNIC document analysis
├── cnic_processor.py        ← CNIC image enhancement (CLAHE + bilateral)
├── customer_screening.py    ← AML + criminal lookup + KYC decision
├── scoring.py               ← Weighted trust score engine
├── pakistan_kyc.py          ← NADRA CNIC format validator
├── cnic_archive.py          ← Session archive manager
├── pdf_export.py            ← ReportLab PDF report generator
├── utils.py                 ← Logging + helper utilities
├── citizen_database.json    ← Bank customer records
├── criminal_records.json    ← FIA criminal watchlist (demo)
└── requirements.txt         ← Python dependencies
```

---

## DIP Pipeline (17 Steps, 5 Categories)

| # | Step | Category | Applied In |
|---|------|----------|-----------|
| 1 | Grayscale Conversion | Color Space | CNIC pre-processing |
| 2 | Histogram Equalization | Histogram | Face detection contrast boost |
| 3 | CLAHE | Histogram | CNIC enhancement |
| 4 | Gaussian Blur | Spatial Filter | Noise removal before edges |
| 5 | Bilateral Filter | Spatial Filter | CNIC text preservation |
| 6 | Sharpening (Unsharp Mask) | Spatial Filter | CNIC OCR preparation |
| 7 | Canny Edge Detection | Edge | Document boundary detection |
| 8 | Sobel X | Edge | Horizontal gradient |
| 9 | Sobel Y | Edge | Vertical gradient |
| 10 | Laplacian | Edge | Liveness sharpness measure |
| 11 | Otsu Thresholding | Threshold | CNIC binarization |
| 12 | Adaptive Threshold | Threshold | Uneven lighting correction |
| 13 | Erosion | Morphological | Noise dots removal |
| 14 | Dilation | Morphological | Text stroke thickening |
| 15 | Closing | Morphological | Gap filling in text |
| 16 | Laplacian (full) | Edge | Forgery edge analysis |
| 17 | DFT Magnitude | Frequency Domain | Periodic artifact detection |

---

## Scoring Formula

```
Trust Score = (Face Confidence × 0.40) + (Document Score × 0.35) + (Signature Similarity × 0.25)

Score ≥ 70  →  LOW RISK    → IDENTITY VERIFIED — SAFE TO PROCEED
Score 45-69 →  MEDIUM RISK → CAUTION — MANUAL REVIEW RECOMMENDED
Score < 45  →  HIGH RISK   → HIGH RISK — TRANSACTION BLOCKED
```

---

## Key Modules & Responsibilities

### `main.py` — Application Controller
- `MainWindow` class with 5-panel layout
- `VerificationWorker` QThread for non-blocking processing
- `WebcamDialog` for live face capture with face detection overlay
- `ComplianceReviewDialog` for AML decisions
- `CnicDataDialog` for CNIC data entry
- Dashboard statistics (total/approved/rejected/review)

### `face_module.py` — Biometric Engine
- `detect_faces_opencv()` — Haar Cascade + Histogram Equalization
- `check_liveness()` — Laplacian variance blur detection
- `compare_live_face_with_cnic()` — Histogram correlation matching
- `run_face_verification()` — Full verification pipeline

### `dip_pipeline.py` + `dip_concepts.py` — Image Processing Core
- 17 DIP transforms across 5 academic categories
- Each function documented with DIP category label
- `run_showcase()` for interactive category browser

### `customer_screening.py` — Intelligence Engine
- `get_customer_profile()` — Full AML/KYC screening
- `screening_decision()` — Approve / Review / Reject logic
- `get_previous_verifications()` — Duplicate fraud detection

### `scoring.py` — Risk Engine
- `calculate_trust_score()` — Weighted biometric formula
- `get_risk_level()` — Three-tier risk classification
- `generate_flags()` — Specific fraud indicator messages

### `pdf_export.py` — Compliance Reporting
- ReportLab PDF generation
- Per-customer KYC report with scores, flags, and decision

---

## Technology Stack

| Component | Library | Version | Purpose |
|-----------|---------|---------|---------|
| GUI Framework | PyQt5 | 5.15.11 | Desktop interface |
| Computer Vision | OpenCV | 4.10.0 | DIP + face detection |
| Image Math | NumPy | 1.26.4 | Array operations |
| Image I/O | Pillow | 10.4.0 | Image format handling |
| PDF Export | ReportLab | 4.2.2 | Compliance reports |

---

## Compliance Standards

- **SBP** — State Bank of Pakistan KYC guidelines
- **NADRA** — National Database format (XXXXX-XXXXXXX-X)
- **FATF** — Anti-Money Laundering screening framework
- **FIA** — Federal Investigation Agency watchlist integration

---

**Version**: 2.0 (Premium Purple UI Release)  
**Status**: Production Ready  
**Last Updated**: May 2026
