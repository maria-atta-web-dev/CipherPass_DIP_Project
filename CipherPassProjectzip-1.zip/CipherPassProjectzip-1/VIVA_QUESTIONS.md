# CipherPass — Viva / Defense Question Bank
## Digital Image Processing (DIP) Course Project

---

## SECTION 1 — PROJECT OVERVIEW

**Q1: What is CipherPass and what problem does it solve?**

CipherPass is a Pakistani banking KYC (Know Your Customer) and AML (Anti-Money Laundering) desktop application. It solves the problem of manual identity fraud at bank counters by automating three checks simultaneously: (1) biometric face verification, (2) CNIC document authenticity analysis using DIP, and (3) real-time cross-referencing against criminal watchlists. Banks in Pakistan are required by the State Bank of Pakistan (SBP) to perform these checks before opening accounts or processing high-value transactions.

---

**Q2: Why did you choose a banking KYC application for your DIP project?**

KYC systems are one of the most practical real-world applications of DIP. Every step of the pipeline — document scanning, face detection, forgery detection, liveness checking — maps directly to a DIP concept. It also has high social relevance: financial fraud costs Pakistan's banking sector billions annually, and NADRA-verified CNIC-based identity is the primary authentication method in the country.

---

**Q3: What is KYC and what is AML?**

- **KYC (Know Your Customer)**: The process a bank uses to verify the identity of a customer before providing services. It includes verifying their CNIC, face, address, and financial history.
- **AML (Anti-Money Laundering)**: The process of checking whether a customer has been involved in financial crimes, terrorism financing, or fraud. Banks must screen customers against watchlists before account opening.

**Where used in code**: `customer_screening.py` → `get_customer_profile()`, `screening_decision()`

---

## SECTION 2 — DIP CONCEPTS (CORE)

**Q4: How many DIP steps does CipherPass use and what are they?**

CipherPass uses a **17-step DIP pipeline** organized into 5 categories:

| Category | Steps |
|----------|-------|
| A. Spatial Domain Filtering | Gaussian Blur, Bilateral Filter, Sharpening |
| B. Edge Detection | Canny, Sobel X, Sobel Y, Laplacian |
| C. Morphological Operations | Erosion, Dilation, Closing |
| D. Frequency Domain | DFT Magnitude Spectrum |
| E. Thresholding & Segmentation | Otsu, Adaptive Threshold |
| + Histogram | Histogram Equalization, CLAHE |
| + Color | Grayscale Conversion |

**Where used**: `dip_pipeline.py` → `run_dip_pipeline()`, `dip_concepts.py` (all functions)

---

**Q5: Explain Grayscale Conversion. Why is it done first?**

Grayscale conversion reduces a 3-channel BGR image to a single intensity channel using the luminance formula:
```
Gray = 0.114×B + 0.587×G + 0.299×R
```
It is done first because most DIP algorithms (edge detection, thresholding, morphological operations) operate on single-channel images. It also reduces computation cost by 3×.

**Where used**: `dip_concepts.py` → `_to_gray()`, applied in every DIP function before processing. Also in `face_module.py` → `detect_faces_opencv()` and `check_liveness()`.

---

**Q6: What is Histogram Equalization and where is it used?**

Histogram Equalization redistributes pixel intensities so that the histogram of the output image is approximately flat (uniform distribution). This improves contrast in images that are too dark or too bright.

**Formula**: Maps each intensity level using the CDF (Cumulative Distribution Function) of the image histogram.

**Where used in CipherPass**:
1. `face_module.py` → `detect_faces_opencv()` — applied to the grayscale frame before Haar Cascade to improve contrast for face detection
2. `dip_pipeline.py` step 3 — visible in the DIP showcase dialog

---

**Q7: What is CLAHE and how is it different from regular Histogram Equalization?**

CLAHE (Contrast Limited Adaptive Histogram Equalization) divides the image into small tiles (default 8×8) and applies histogram equalization to each tile independently, with a contrast limit (clip limit) to prevent noise amplification. Regular histogram equalization is global — it can over-enhance background areas and wash out important features.

CLAHE is better for CNIC documents because CNIC cards often have locally dark areas (holograms, printed text) alongside bright areas.

**Where used**: `dip_concepts.py` → `apply_clahe()`, called from `cnic_processor.py` → `enhance_cnic_image()` for CNIC scan preprocessing.

---

**Q8: Explain Gaussian Blur and why you use it before edge detection.**

Gaussian Blur convolves the image with a Gaussian kernel to smooth it. The Gaussian kernel gives higher weight to the center pixel and progressively lower weight to neighbors based on a normal distribution with standard deviation σ.

```
G(x,y) = (1/2πσ²) × e^(-(x²+y²)/2σ²)
```

It removes high-frequency noise before edge detection. Without it, tiny variations in pixel intensity get misidentified as edges by Canny or Sobel operators.

**Where used**: `dip_concepts.py` → `apply_gaussian_blur()` (step 5 in pipeline). Also inside `apply_sharpening()` as the blurred copy for unsharp masking.

---

**Q9: Explain Canny Edge Detection step by step.**

Canny is a multi-stage edge detector:
1. **Gaussian Smoothing** — remove noise (σ=1.4 typically)
2. **Gradient Calculation** — Sobel X and Y to find intensity gradients
3. **Non-Maximum Suppression** — thin edges by keeping only local maxima along gradient direction
4. **Double Thresholding** — pixels above `high` threshold = strong edges, between `low` and `high` = weak edges, below `low` = not edges
5. **Edge Tracking by Hysteresis** — weak edges are kept only if connected to a strong edge

**Where used**: `dip_concepts.py` → `apply_canny(low=50, high=150)` — step 8 in pipeline. Used for document boundary detection to identify CNIC card edges.

---

**Q10: What are Sobel operators and what do they detect?**

Sobel operators compute the gradient of image intensity in horizontal (X) and vertical (Y) directions using convolution with 3×3 kernels:

```
Sobel X:  [-1  0  +1]     Sobel Y:  [-1  -2  -1]
          [-2  0  +2]                [ 0   0   0]
          [-1  0  +1]                [+1  +2  +1]
```

- **Sobel X** detects vertical edges (changes in horizontal direction)
- **Sobel Y** detects horizontal edges (changes in vertical direction)

**Where used**: `dip_concepts.py` → `apply_sobel_x()` (step 9), `apply_sobel_y()` (step 10). Used to analyze edge directions in CNIC documents.

---

**Q11: What is the Laplacian operator and how does it detect forgery/liveness?**

The Laplacian is the second-order derivative of image intensity. It detects regions of rapid intensity change (edges) by measuring how much the center pixel differs from its neighbors:

```
Laplacian kernel: [ 0  -1   0]
                  [-1  +4  -1]
                  [ 0  -1   0]
```

**Liveness detection using Laplacian variance**: The variance of the Laplacian image measures image sharpness. Real live faces have texture and sharpness (high variance). A printed photo held up to the camera is blurrier (low variance).

```python
variance = cv2.Laplacian(gray, cv2.CV_64F).var()
if variance > 150: liveness = 0.9  # Very sharp = likely real face
elif variance > 50: liveness = 0.4  # Moderate = uncertain
else: liveness = 0.1                # Blurry = likely fake/photo attack
```

**Where used**: `face_module.py` → `check_liveness()`, `dip_concepts.py` → `apply_laplacian()` (step 16).

---

**Q12: Explain the three morphological operations used in CipherPass.**

Morphological operations process binary or grayscale images based on the shape (structuring element):

| Operation | What it does | Used for |
|-----------|-------------|----------|
| **Erosion** | Shrinks bright regions — removes small noise dots | Cleaning small noise artifacts from binarized CNIC |
| **Dilation** | Expands bright regions — fills small holes | Thickening thin text strokes in CNIC for better OCR |
| **Closing** | Dilation then Erosion — fills gaps between characters | Joining broken text characters in CNIC documents |

**Where used**: `dip_concepts.py` → `apply_erosion()`, `apply_dilation()`, `apply_closing()` — steps 13, 14, 15 in pipeline.

---

**Q13: What is Otsu Thresholding and how does it work automatically?**

Otsu's method automatically finds the optimal threshold value that maximizes the inter-class variance (variance between foreground and background pixels). It analyzes the image histogram to find the threshold T that best separates the two pixel groups.

This eliminates the need to manually choose a threshold value.

**Where used**: `dip_concepts.py` → `apply_otsu_threshold()` — step 11 in pipeline. Used for binarizing CNIC documents.

---

**Q14: What is Adaptive Thresholding and when is it better than Otsu?**

Adaptive Thresholding computes a different threshold for each small region of the image based on the local mean or Gaussian-weighted mean of the neighborhood. This handles non-uniform lighting (e.g., a CNIC card photographed with uneven lighting — one corner dark, one bright).

Otsu uses a single global threshold and fails when lighting varies across the image.

**Where used**: `dip_concepts.py` → `apply_adaptive_threshold()` — step 12 in pipeline.

---

**Q15: What is the Discrete Fourier Transform (DFT) and how is it used for forgery detection?**

The DFT converts an image from the spatial domain to the frequency domain, showing which spatial frequencies (patterns) are present in the image. Authentic documents have a natural, irregular frequency spectrum. Printed or photocopied documents often show periodic patterns (halftone dots, scanning artifacts) that appear as bright spots in the magnitude spectrum.

```python
dft = cv2.dft(np.float32(gray), flags=cv2.DFT_COMPLEX_OUTPUT)
dft_shift = np.fft.fftshift(dft)
magnitude = 20 * np.log(cv2.magnitude(dft_shift[:,:,0], dft_shift[:,:,1]))
```

**Where used**: `dip_concepts.py` → `apply_dft_magnitude()` — step 17 in pipeline.

---

**Q16: What is Bilateral Filtering and why is it used for CNIC enhancement instead of Gaussian Blur?**

Bilateral filtering smooths an image while preserving edges. It considers both spatial closeness (like Gaussian) AND intensity similarity. Pixels with very different intensity from the center pixel get very low weight even if they are spatially close.

This means it smooths flat areas (background) without blurring text edges on the CNIC card — making the text sharper while reducing background noise.

**Where used**: `dip_concepts.py` → `apply_bilateral_filter()` — step 6 in pipeline. Also explicitly in `cnic_processor.py` for CNIC enhancement.

---

## SECTION 3 — FACE VERIFICATION

**Q17: How does Haar Cascade face detection work?**

Haar Cascade is a machine learning based object detection method:
1. Uses **Haar-like features** (rectangular filters that compute differences between pixel sums in adjacent regions) as feature detectors
2. Trained using **AdaBoost** to select the most discriminative features from thousands of candidates
3. Uses a **cascade classifier** — multiple stages of increasingly complex tests; a face is rejected early if it fails easy tests, making it very fast
4. Input must be grayscale + histogram equalized for better contrast

**Where used**: `face_module.py` → `detect_faces_opencv()` using `haarcascade_frontalface_default.xml`. Also `main.py` → `FaceDetector.detect()` for live webcam preview.

---

**Q18: How does liveness detection prevent photo attacks?**

A photo attack is when someone holds a printed photo of another person in front of the camera. CipherPass uses **Laplacian variance** to distinguish real faces from printed photos:
- Real faces have natural skin texture, micro-details, and environmental depth — high sharpness (high Laplacian variance)
- Printed photos lack that texture and appear slightly blurry — low variance

Threshold: variance > 150 → score 0.9 (live), variance < 50 → score 0.1 (fake).

**Where used**: `face_module.py` → `check_liveness(face_region)`

---

**Q19: How does face matching between the CNIC photo and live capture work?**

CipherPass uses **histogram correlation** to compare faces:
1. Extract face regions from both CNIC image and live capture
2. Convert both to grayscale
3. Compute normalized grayscale histograms (256 bins)
4. Compare using `cv2.HISTCMP_CORREL` (Pearson correlation coefficient)
5. Correlation ≥ 0.32 → match accepted

This is a lightweight approach that works without deep learning models.

**Where used**: `face_module.py` → `compare_live_face_with_cnic()`

---

## SECTION 4 — SCORING & DECISIONS

**Q20: Explain the Trust Score formula and why those specific weights.**

```
Trust Score = (Face × 0.40) + (Document × 0.35) + (Signature × 0.25)
```

- **Face (40%)** — Primary biometric. Direct biological link between person and CNIC. Hardest to fake.
- **Document (35%)** — CNIC authenticity. Essential but can be forged with effort.
- **Signature (25%)** — Behavioral biometric. Useful but least reliable alone.

The weights reflect standard banking risk weighting where biometric identity is most trusted.

**Where used**: `scoring.py` → `calculate_trust_score(face_conf, doc_conf, sig_sim)`

---

**Q21: What are the three risk levels and what happens at each?**

| Score | Risk Level | Action |
|-------|-----------|--------|
| ≥ 70 | LOW | Identity Verified — proceed with transaction |
| 45–69 | MEDIUM | Caution — send to compliance officer for manual review |
| < 45 | HIGH | Transaction blocked — flag for fraud department |

Medium risk triggers the `ComplianceReviewDialog` where a compliance officer sees the full AML report and makes the final decision.

**Where used**: `scoring.py` → `get_risk_level()`, `main.py` → `_on_result()` and `_show_compliance_review()`

---

**Q22: What fraud flags does the system generate?**

The system generates specific flags based on individual score components:
- Face confidence < 0.5 → "Face verification failed — Identity mismatch"
- No face detected → "No face detected in image"
- Multiple faces → "Multiple faces detected"
- Liveness < 0.4 → "Liveness check failed — Possible photo attack"
- Document confidence < 0.4 → "Document forgery detected"
- Signature similarity < 0.3 → "Signature mismatch — Identity inconsistency"

**Where used**: `scoring.py` → `generate_flags()`, displayed in `main.py` → `_on_result()`

---

## SECTION 5 — CRIMINAL SCREENING & AML

**Q23: How does the criminal screening work?**

1. User enters CNIC number in the application
2. Before verification even starts, `get_customer_profile()` is called
3. It looks up the CNIC in `criminal_records.json` (simulating an FIA watchlist)
4. If a criminal record exists with `risk_level = "high"`, a **pre-verification warning dialog** appears immediately
5. The compliance officer can proceed or abort
6. The final decision always reflects criminal record status regardless of biometric scores

**Where used**: `customer_screening.py` → `get_customer_profile()`, `find_criminal_record()`, `screening_decision()`. Triggered in `main.py` → `_run_pre_check()`.

---

**Q24: How does duplicate detection work?**

Every completed verification session is saved to `verification_data/history.json`. When the same CNIC is verified again, `get_previous_verifications()` returns the count of prior sessions. If count ≥ 2, the system flags it as a potential **duplicate fraud / account takeover attempt** and escalates to manual review.

**Where used**: `customer_screening.py` → `save_verification_history()`, `get_previous_verifications()`, called from `main.py` after each successful verification.

---

**Q25: What is NADRA CNIC format validation?**

Pakistan's NADRA issues CNICs in the format: `XXXXX-XXXXXXX-X` (5 digits - 7 digits - 1 digit). The first 5 digits represent the district code. CipherPass validates this format using regex before any lookup to prevent invalid queries.

```python
Pattern: r"^\d{5}-\d{7}-\d{1}$"
```

**Where used**: `pakistan_kyc.py` → `validate_pakistan_cnic()`, called from `main.py` before screening.

---

## SECTION 6 — SOFTWARE ARCHITECTURE

**Q26: Why did you use PyQt5 for the GUI?**

PyQt5 offers:
- Native OS look-and-feel with full custom styling via QSS (Qt Style Sheets)
- QThread for non-blocking background processing (verification runs on a separate thread)
- Signal-slot mechanism for thread-safe UI updates
- QLabel with QPixmap for real-time webcam frame display
- Cross-platform support (Windows, Linux, macOS)

**Where used**: `main.py` — `QMainWindow`, `QThread` (`VerificationWorker`), `QDialog` classes.

---

**Q27: Why is verification run in a separate thread (QThread)?**

PyQt5's GUI runs on the main thread. If CPU-intensive operations (OpenCV processing, DIP pipeline, JSON lookups) ran on the main thread, the UI would freeze and become unresponsive during verification. `VerificationWorker` extends `QThread` and emits a `result_ready` signal when done — the main thread receives it and updates the UI safely.

**Where used**: `main.py` → `VerificationWorker(QThread)`, `result_ready = pyqtSignal(dict)`.

---

**Q28: How does the DIP Showcase Dialog work?**

The DIP Showcase Dialog (`dip_showcase_dialog.py`) is an interactive viewer that:
1. Takes the current verification image (CNIC or face)
2. Runs the full 17-step pipeline via `run_dip_pipeline()`
3. Displays results organized by DIP category in a scrollable grid
4. Each tile shows the image + step label + a description of the DIP concept
5. Users can filter by category using the dropdown

**Where used**: `dip_showcase_dialog.py` → `DipShowcaseDialog`, launched from `main.py` toolbar button.

---

**Q29: How is the PDF report generated?**

`pdf_export.py` uses the **ReportLab** library to programmatically create a PDF containing:
- Customer identity details
- Trust score with graphical representation
- List of fraud flags
- DIP processing summary
- Final decision with recommendation

ReportLab draws content using absolute coordinates onto a canvas object, which is then saved as a PDF file.

**Where used**: `pdf_export.py` → `generate_pdf_report()`, called from `main.py` on approved verifications.

---

## SECTION 7 — ADVANCED / CRITICAL QUESTIONS

**Q30: What are the limitations of your face matching approach?**

The histogram correlation approach is lightweight but limited:
- It compares overall intensity distribution, not facial structure
- Identical twins or people with similar complexions may get false matches
- Different lighting conditions significantly affect histogram similarity
- The 0.32 threshold was chosen empirically — not trained on real data

A production system would use deep learning face embeddings (e.g., FaceNet, ArcFace) for much higher accuracy.

---

**Q31: How would you improve liveness detection in production?**

Current approach: Laplacian variance (single-frame blur detection)

Production improvements:
1. **3D depth sensing** — IR cameras detect flat photos
2. **Blink detection** — ask user to blink (temporal liveness)
3. **Challenge-response** — ask user to turn left/right
4. **Micro-texture analysis** — CNNs trained to detect printed paper texture vs. skin
5. **Multi-frame consistency** — check that the face moves naturally across frames

---

**Q32: Is this system compliant with Pakistan's data protection regulations?**

The current demo system stores verification sessions locally in JSON files. A production deployment would need to comply with:
- **SBP Cybersecurity Framework** — encryption of biometric data at rest and in transit
- **PECA 2016** — Pakistan Electronic Crimes Act for data handling
- **NADRA data sharing regulations** — formal API agreement required for live CNIC verification
- **Data minimization** — biometric images should not be stored after verification is complete

---

**Q33: Why did you use JSON files instead of a real database?**

For academic demonstration purposes, JSON files are sufficient and keep the project dependency-free (no database server needed). In production:
- Criminal records would be fetched via secure REST API from an FIA/NADRA server
- Customer records would be in a bank's core banking system (Oracle, Temenos, etc.)
- Verification history would go into a PostgreSQL/Oracle database with encryption

---

**Q34: Explain the complete flow when a bank teller uses CipherPass.**

1. Customer presents CNIC at counter
2. Teller enters CNIC number → system immediately runs pre-screening
3. If criminal record found → warning dialog shown → teller decides to proceed or abort
4. Teller uploads/scans CNIC image → DIP pipeline runs (17 steps)
5. Teller captures live face photo via webcam → face detection + liveness check
6. System computes trust score: `(Face×0.40) + (Document×0.35) + (Signature×0.25)`
7. Score ≥ 70 → auto-approve; Score 45–69 → send to compliance officer; Score < 45 → block
8. Compliance officer reviews AML report in dedicated dialog → approves or rejects
9. PDF report generated → verification record saved to history
10. Result shown to teller → account opening proceeds or is stopped

---

**Q35: What is the DFT used for in forgery detection?**

A genuine printed CNIC has a specific frequency fingerprint. When forged (photocopied, digitally altered):
- **Photocopying** introduces halftone dot patterns (periodic patterns = peaks in DFT at regular intervals)
- **Digital editing** (clone stamp, fill areas) creates regions of unnaturally uniform frequency
- **Scanner artifacts** create horizontal/vertical line patterns visible as cross-shaped DFT spikes

By visualizing the DFT magnitude spectrum, trained operators can spot anomalies not visible to the naked eye.

**Where used**: `dip_concepts.py` → `apply_dft_magnitude()` — step 17 in the showcase pipeline.

---

## QUICK REFERENCE — WHERE EACH DIP CONCEPT IS USED

| Concept | File | Function | Purpose in CipherPass |
|---------|------|----------|----------------------|
| Grayscale | `dip_concepts.py` | `_to_gray()` | Pre-processing for all algorithms |
| Hist. Equalization | `face_module.py` | `detect_faces_opencv()` | Improve face detection contrast |
| CLAHE | `cnic_processor.py` | `enhance_cnic_image()` | Enhance CNIC scan quality |
| Gaussian Blur | `dip_concepts.py` | `apply_gaussian_blur()` | Noise removal |
| Bilateral Filter | `dip_concepts.py` | `apply_bilateral_filter()` | CNIC text-preserving denoise |
| Sharpening | `dip_concepts.py` | `apply_sharpening()` | CNIC OCR preparation |
| Canny Edge | `dip_concepts.py` | `apply_canny()` | Document boundary detection |
| Sobel X/Y | `dip_concepts.py` | `apply_sobel_x/y()` | Gradient direction analysis |
| Laplacian | `face_module.py` | `check_liveness()` | Photo attack detection |
| Otsu Threshold | `dip_concepts.py` | `apply_otsu_threshold()` | CNIC binarization |
| Adaptive Threshold | `dip_concepts.py` | `apply_adaptive_threshold()` | Non-uniform lighting |
| Erosion | `dip_concepts.py` | `apply_erosion()` | Noise removal |
| Dilation | `dip_concepts.py` | `apply_dilation()` | Text stroke thickening |
| Closing | `dip_concepts.py` | `apply_closing()` | Gap filling in text |
| DFT | `dip_concepts.py` | `apply_dft_magnitude()` | Forgery frequency analysis |
| Haar Cascade | `face_module.py` | `detect_faces_opencv()` | Face detection |
| Histogram Compare | `face_module.py` | `compare_live_face_with_cnic()` | CNIC–live face matching |
