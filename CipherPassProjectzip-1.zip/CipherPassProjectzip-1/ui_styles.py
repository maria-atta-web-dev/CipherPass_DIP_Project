"""
CipherPass — Enterprise Dark Theme for PyQt5
Professional charcoal palette with single blue accent
Inspired by Bloomberg Terminal / enterprise identity software
"""

APP_STYLESHEET = """
/* ─── Global ───────────────────────────────────────── */
QMainWindow, QWidget {
    background-color: #0d1117;
    color: #e6edf3;
    font-family: 'Segoe UI', 'Inter', 'Helvetica Neue', Arial, sans-serif;
    font-size: 12px;
}

/* ─── Group Boxes ──────────────────────────────────── */
QGroupBox {
    border: 1px solid #21262d;
    border-top: 2px solid #1f6feb;
    border-radius: 6px;
    margin-top: 18px;
    padding: 12px 12px 10px 12px;
    background-color: #161b22;
    font-weight: 600;
    font-size: 11px;
    color: #e6edf3;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 0px 8px;
    color: #8b949e;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
}

/* ─── Text Input Fields ────────────────────────────── */
QLineEdit {
    background-color: #0d1117;
    border: 1px solid #30363d;
    border-radius: 5px;
    padding: 7px 10px;
    color: #e6edf3;
    font-size: 12px;
    margin: 1px 0px;
    selection-background-color: #1f6feb;
}

QLineEdit:focus {
    border: 1px solid #1f6feb;
    background-color: #161b22;
    outline: none;
}

QLineEdit:hover {
    border: 1px solid #388bfd;
}

QLineEdit::placeholder {
    color: #484f58;
}

/* ─── Buttons (global base) ────────────────────────── */
QPushButton {
    background-color: #21262d;
    color: #c9d1d9;
    border: 1px solid #30363d;
    padding: 7px 14px;
    border-radius: 5px;
    font-weight: 500;
    font-size: 12px;
    min-width: 70px;
}

QPushButton:hover {
    background-color: #30363d;
    color: #e6edf3;
    border: 1px solid #8b949e;
}

QPushButton:pressed {
    background-color: #161b22;
    border: 1px solid #1f6feb;
    color: #58a6ff;
}

QPushButton:disabled {
    background-color: #161b22;
    color: #30363d;
    border: 1px solid #21262d;
}

/* ─── Text Editing Areas ───────────────────────────── */
QTextEdit {
    background-color: #0d1117;
    border: 1px solid #21262d;
    border-radius: 5px;
    color: #8b949e;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 11px;
    padding: 8px;
    selection-background-color: #1f6feb;
}

QTextEdit:focus {
    border: 1px solid #30363d;
}

/* ─── Progress Bar ─────────────────────────────────── */
QProgressBar {
    background-color: #21262d;
    border: none;
    border-radius: 3px;
    text-align: center;
    color: #8b949e;
    font-weight: 600;
    font-size: 10px;
    min-height: 14px;
}

QProgressBar::chunk {
    background-color: #1f6feb;
    border-radius: 3px;
}

/* ─── Scroll Areas ─────────────────────────────────── */
QScrollArea {
    border: none;
    background: transparent;
}

QScrollBar:vertical {
    background: #0d1117;
    width: 6px;
    border-radius: 3px;
}

QScrollBar::handle:vertical {
    background: #30363d;
    border-radius: 3px;
    min-height: 24px;
}

QScrollBar::handle:vertical:hover {
    background: #8b949e;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

/* ─── Tables ───────────────────────────────────────── */
QTableWidget {
    background-color: #161b22;
    gridline-color: #21262d;
    border-radius: 5px;
    border: 1px solid #21262d;
    selection-background-color: #1f3c6e;
}

QTableWidget::item {
    padding: 5px;
    color: #e6edf3;
}

QTableWidget::item:selected {
    background-color: #1f3c6e;
}

QHeaderView::section {
    background-color: #161b22;
    color: #8b949e;
    padding: 7px;
    border: none;
    border-bottom: 1px solid #21262d;
    font-weight: 600;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* ─── Combo Boxes ──────────────────────────────────── */
QComboBox {
    background-color: #21262d;
    border: 1px solid #30363d;
    border-radius: 5px;
    padding: 7px 10px;
    color: #e6edf3;
    font-size: 12px;
    min-width: 100px;
}

QComboBox:hover {
    border: 1px solid #8b949e;
}

QComboBox::drop-down {
    border: none;
    width: 20px;
}

QComboBox QAbstractItemView {
    background-color: #161b22;
    border: 1px solid #30363d;
    color: #e6edf3;
    selection-background-color: #1f3c6e;
    border-radius: 4px;
    outline: none;
}

/* ─── Dialogs ──────────────────────────────────────── */
QDialog {
    background-color: #0d1117;
    color: #e6edf3;
}

/* ─── Labels ───────────────────────────────────────── */
QLabel {
    color: #8b949e;
    font-size: 12px;
}

/* ─── Message Boxes ────────────────────────────────── */
QMessageBox {
    background-color: #161b22;
    color: #e6edf3;
}

QMessageBox QLabel {
    color: #c9d1d9;
}

QMessageBox QPushButton {
    min-width: 60px;
}

/* ─── Frames ───────────────────────────────────────── */
QFrame {
    background-color: transparent;
    border: none;
}

QFrame#card {
    background-color: #161b22;
    border: 1px solid #21262d;
    border-radius: 6px;
    padding: 12px;
}

/* ─── Splitter ─────────────────────────────────────── */
QSplitter::handle {
    background-color: #21262d;
    width: 1px;
}

QSplitter::handle:hover {
    background-color: #1f6feb;
}

/* ─── Tooltips ─────────────────────────────────────── */
QToolTip {
    background-color: #161b22;
    color: #c9d1d9;
    border: 1px solid #30363d;
    border-radius: 4px;
    padding: 4px 8px;
    font-size: 11px;
}
"""

# ── Header style ──────────────────────────────────────
HEADER_STYLE = """
    background-color: #161b22;
    border-bottom: 1px solid #21262d;
    padding: 0px 16px;
    color: #e6edf3;
"""

# ── Button variants ───────────────────────────────────
BTN_PRIMARY = """
    background-color: #1f6feb;
    color: #ffffff;
    font-weight: 600;
    border-radius: 5px;
    padding: 7px 14px;
    border: 1px solid #388bfd;
    font-size: 12px;
"""

BTN_PRIMARY_HOVER = """
    background-color: #388bfd;
    color: #ffffff;
    font-weight: 600;
    border-radius: 5px;
    padding: 7px 14px;
    border: 1px solid #58a6ff;
    font-size: 12px;
"""

BTN_DANGER = """
    background-color: #21262d;
    color: #f85149;
    font-weight: 600;
    border-radius: 5px;
    padding: 7px 14px;
    border: 1px solid #da3633;
    font-size: 12px;
"""

BTN_SUCCESS = """
    background-color: #21262d;
    color: #3fb950;
    font-weight: 600;
    border-radius: 5px;
    padding: 7px 14px;
    border: 1px solid #238636;
    font-size: 12px;
"""

BTN_WARNING = """
    background-color: #21262d;
    color: #e3b341;
    font-weight: 600;
    border-radius: 5px;
    padding: 7px 14px;
    border: 1px solid #9e6a03;
    font-size: 12px;
"""

BTN_VERIFY = """
    background-color: #1f6feb;
    color: #ffffff;
    font-size: 13px;
    font-weight: 700;
    padding: 12px 22px;
    border-radius: 6px;
    border: 1px solid #388bfd;
    min-width: 130px;
    letter-spacing: 0.5px;
"""

BTN_VERIFY_HOVER = """
    background-color: #388bfd;
    color: #ffffff;
    font-size: 13px;
    font-weight: 700;
    padding: 12px 22px;
    border-radius: 6px;
    border: 1px solid #58a6ff;
    min-width: 130px;
    letter-spacing: 0.5px;
"""

# ── Accent palette ────────────────────────────────────
ACCENT_COLOR   = "#1f6feb"
ACCENT_DARK    = "#1158c7"
ERROR_COLOR    = "#f85149"
SUCCESS_COLOR  = "#3fb950"
WARNING_COLOR  = "#e3b341"
INFO_COLOR     = "#58a6ff"
