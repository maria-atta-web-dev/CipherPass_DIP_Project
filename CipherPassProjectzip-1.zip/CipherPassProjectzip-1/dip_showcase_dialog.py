"""
================================================================================
DIP SHOWCASE DIALOG — CipherPass
================================================================================
Visual grid showing every DIP concept applied to the last verification image.
Each tile shows: step image + label + one-line DIP description.
================================================================================
"""

import cv2
import numpy as np
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QWidget, QGridLayout, QFrame, QComboBox,
    QSizePolicy, QTabWidget,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QImage, QFont

from dip_concepts import run_showcase, get_quality_report, SHOWCASE_STEPS


# ── Colour for each DIP category letter (charcoal + single-accent palette) ───
CATEGORY_COLOURS = {
    "A": ("#0f1a2e", "#1f6feb"),   # Spatial Filtering  — blue
    "B": ("#0d1f14", "#3fb950"),   # Edge Detection     — green
    "C": ("#1f1608", "#e3b341"),   # Morphological      — amber
    "D": ("#0d1224", "#388bfd"),   # Frequency Domain   — light blue
    "E": ("#1a0d0d", "#f85149"),   # Thresholding       — red
    "F": ("#0a1a1a", "#58a6ff"),   # Colour Space       — sky blue
    "G": ("#131620", "#8b949e"),   # Histogram          — slate
    "H": ("#161b22", "#6e7681"),   # Quality Assessment — muted gray
}

CATEGORY_NAMES = {
    "A": "Spatial Domain Filtering",
    "B": "Edge Detection",
    "C": "Morphological Operations",
    "D": "Frequency Domain (DFT)",
    "E": "Thresholding & Segmentation",
    "F": "Colour Space Conversion",
    "G": "Histogram Operations",
    "H": "Image Quality",
}


def _bgr_to_pixmap(img: np.ndarray, w: int = 140, h: int = 110) -> QPixmap:
    """Convert a BGR numpy array to a scaled QPixmap."""
    if img is None or img.size == 0:
        return QPixmap()
    if len(img.shape) == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    qimg = QImage(rgb.data, rgb.shape[1], rgb.shape[0], rgb.strides[0], QImage.Format_RGB888)
    return QPixmap.fromImage(qimg).scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)


def _cat(desc: str) -> str:
    """Extract category letter from description string like 'A: ...' """
    return desc[0] if desc and desc[0] in CATEGORY_COLOURS else "A"


class DipTile(QFrame):
    """Single DIP step tile: image + label + description."""

    def __init__(self, label: str, description: str, img: np.ndarray, parent=None):
        super().__init__(parent)
        cat = _cat(description)
        bg_dark, accent = CATEGORY_COLOURS.get(cat, ("#161b22", "#388bfd"))

        self.setStyleSheet(
            f"QFrame {{ background:{bg_dark}; border:1px solid {accent}44;"
            f" border-radius:5px; }}"
        )
        self.setFixedSize(175, 195)

        lay = QVBoxLayout(self)
        lay.setSpacing(3)
        lay.setContentsMargins(6, 6, 6, 6)

        # image
        img_lbl = QLabel()
        img_lbl.setAlignment(Qt.AlignCenter)
        img_lbl.setPixmap(_bgr_to_pixmap(img, 155, 115))
        img_lbl.setStyleSheet("border:none;")
        lay.addWidget(img_lbl)

        # label
        name_lbl = QLabel(label)
        name_lbl.setAlignment(Qt.AlignCenter)
        name_lbl.setStyleSheet(
            f"color:{accent}; font-size:11px; font-weight:600; border:none;"
        )
        name_lbl.setWordWrap(True)
        lay.addWidget(name_lbl)

        # description (category letter stripped)
        desc_clean = description[3:] if len(description) > 3 and description[1] == ":" else description
        desc_lbl = QLabel(desc_clean)
        desc_lbl.setAlignment(Qt.AlignCenter)
        desc_lbl.setStyleSheet("color:#484f58; font-size:9px; border:none;")
        desc_lbl.setWordWrap(True)
        lay.addWidget(desc_lbl)


class DipShowcaseDialog(QDialog):
    """
    Full-screen dialog showing all DIP steps in a scrollable grid,
    grouped by category in tabs.
    """

    def __init__(self, parent=None, image: np.ndarray = None, image_label: str = "Input"):
        super().__init__(parent)
        self.setWindowTitle("DIP Showcase — CipherPass")
        self.setMinimumSize(1100, 720)
        self.setStyleSheet(
            "QDialog { background-color:#0d1117; color:#e6edf3; }"
            "QTabWidget::pane { border:1px solid #21262d; }"
            "QTabBar::tab { background:#161b22; color:#484f58; padding:7px 18px;"
            "  border-radius:4px 4px 0 0; font-size:11px; }"
            "QTabBar::tab:selected { background:#1c2128; color:#e6edf3;"
            "  border-bottom:2px solid #1f6feb; }"
            "QScrollArea { border:none; background:#0d1117; }"
            "QWidget { background:#0d1117; }"
        )

        self._image = image
        self._image_label = image_label
        self._results = run_showcase(image) if image is not None else []

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 10)
        root.setSpacing(10)

        # ── title row ────────────────────────────────────────────────────────
        title_row = QHBoxLayout()
        title = QLabel("Digital Image Processing Showcase")
        title.setStyleSheet(
            "color:#e6edf3; font-size:16px; font-weight:600;"
        )
        title_row.addWidget(title)
        title_row.addStretch()

        # quality badge
        if image is not None:
            qr = get_quality_report(image)
            q_lbl = QLabel(
                f"{qr['resolution']}  |  Blur: {qr['blur']}  |  {qr['verdict']}"
            )
            q_lbl.setStyleSheet(
                "background:#161b22; color:#8b949e; border:1px solid #30363d;"
                " border-radius:4px; padding:4px 12px; font-size:11px;"
            )
            title_row.addWidget(q_lbl)

        # source selector
        self.src_combo = QComboBox()
        self.src_combo.addItem(image_label)
        self.src_combo.setStyleSheet(
            "background:#21262d; color:#e6edf3; border:1px solid #30363d;"
            " border-radius:4px; padding:4px 10px; font-size:11px; min-width:140px;"
        )
        title_row.addWidget(self.src_combo)
        root.addLayout(title_row)

        # ── legend ───────────────────────────────────────────────────────────
        legend = QHBoxLayout()
        legend.setSpacing(5)
        for letter, name in CATEGORY_NAMES.items():
            _, accent = CATEGORY_COLOURS[letter]
            chip = QLabel(f"  {letter}: {name}  ")
            chip.setStyleSheet(
                f"background:{CATEGORY_COLOURS[letter][0]}; color:{accent};"
                f" border:1px solid {accent}44; border-radius:3px;"
                f" font-size:9px; padding:2px 4px;"
            )
            legend.addWidget(chip)
        legend.addStretch()
        root.addLayout(legend)

        # ── tab widget ───────────────────────────────────────────────────────
        tabs = QTabWidget()
        root.addWidget(tabs, 1)

        # "All Steps" tab
        all_scroll = self._make_scroll(self._results)
        tabs.addTab(all_scroll, f"All Steps ({len(self._results)})")

        # per-category tabs
        for letter, cat_name in CATEGORY_NAMES.items():
            subset = [
                (lbl, desc, img_arr)
                for lbl, desc, img_arr in self._results
                if _cat(desc) == letter
            ]
            if not subset:
                continue
            scroll = self._make_scroll(subset)
            tabs.addTab(scroll, f"{letter}: {cat_name.split('(')[0].strip()} ({len(subset)})")

        # ── bottom bar ───────────────────────────────────────────────────────
        bot = QHBoxLayout()
        bot.addStretch()
        close_btn = QPushButton("Close")
        close_btn.setFixedHeight(34)
        close_btn.setStyleSheet(
            "background:#21262d; color:#c9d1d9; border-radius:5px; border:1px solid #30363d;"
            " font-weight:600; padding:0 20px; font-size:12px;"
        )
        close_btn.clicked.connect(self.accept)
        bot.addWidget(close_btn)
        root.addLayout(bot)

    # ── helpers ──────────────────────────────────────────────────────────────

    def _make_scroll(self, results: list) -> QScrollArea:
        """Build a scrollable grid of DipTile widgets."""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        grid = QGridLayout(content)
        grid.setSpacing(8)
        grid.setContentsMargins(8, 8, 8, 8)

        cols = 6
        for idx, (label, description, img_arr) in enumerate(results):
            tile = DipTile(label, description, img_arr, content)
            grid.addWidget(tile, idx // cols, idx % cols)

        # fill last row
        rem = len(results) % cols
        if rem:
            for c in range(rem, cols):
                spacer = QWidget()
                spacer.setFixedSize(175, 195)
                grid.addWidget(spacer, len(results) // cols, c)

        scroll.setWidget(content)
        return scroll
