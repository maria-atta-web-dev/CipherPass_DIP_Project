"""
CipherPass — Encrypted Identity Clearance & Intelligence Platform
=================================================================
Biometric identity verification, criminal intelligence, and AML compliance.
"""

import os
import re
import sys
import json
import cv2
import numpy as np
from datetime import datetime
from pathlib import Path
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QLineEdit, QTextEdit, QGroupBox, QMessageBox,
    QFileDialog, QDialog, QProgressBar, QFrame, QSizePolicy, QScrollArea,
    QSplitter,
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QPixmap, QImage, QFont

from face_module import run_face_verification
from document_module import analyze_document
from scoring import calculate_trust_score, get_risk_level, generate_flags
from utils import log_message, numpy_to_pixmap
from customer_screening import get_customer_profile, normalize_cnic, save_verification_history
from pakistan_kyc import validate_pakistan_cnic
from dip_pipeline import run_dip_pipeline, get_dip_summary
from dip_showcase_dialog import DipShowcaseDialog
from cnic_processor import enhance_cnic_image, normalize_cnic_entered, is_valid_person_name
from cnic_archive import save_cnic_archive
from ui_styles import (
    APP_STYLESHEET, HEADER_STYLE, BTN_PRIMARY, BTN_DANGER,
    BTN_SUCCESS, BTN_WARNING, BTN_VERIFY
)
from pdf_export import generate_pdf_report

DATABASE_FILE = "citizen_database.json"
APP_NAME = "CipherPass"
APP_TAGLINE = "Encrypted Identity  ·  Criminal Intelligence  ·  AML Screening  ·  Fraud Prevention"


def load_database():
    if os.path.exists(DATABASE_FILE):
        with open(DATABASE_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {
        "42101-1234567-1": {
            "name": "Ahmed Raza", "father": "Muhammad Raza", "cnic": "42101-1234567-1",
            "address": "Karachi", "dob": "15/08/1990", "trust_score": 98,
        },
        "12345-6789012-3": {
            "name": "Hassan Ali", "father": "Muhammad Ali",
            "cnic": "12345-6789012-3", "address": "Karachi", "dob": "01/01/1985", "trust_score": 25,
        },
    }


OFFICIAL_DATABASE = load_database()


def bank_record_for_cnic(cnic):
    key = normalize_cnic(cnic)
    if not key:
        return None
    for k, v in OFFICIAL_DATABASE.items():
        if normalize_cnic(k) == key:
            return v
    return None


class FaceDetector:
    @staticmethod
    def detect(img):
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )
        faces = cascade.detectMultiScale(gray, 1.1, 5, minSize=(60, 60))
        out = img.copy()
        for (x, y, w, h) in faces:
            cv2.rectangle(out, (x, y), (x + w, y + h), (0, 255, 0), 2)
        return out, len(faces)


class WebcamThread(QThread):
    change_pixmap = pyqtSignal(np.ndarray)

    def __init__(self):
        super().__init__()
        self._run = True
        self.cap = None

    def run(self):
        self.cap = cv2.VideoCapture(0)
        while self._run and self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if ret:
                out, _ = FaceDetector.detect(frame)
                self.change_pixmap.emit(out)
            self.msleep(33)

    def stop(self):
        self._run = False
        if self.cap:
            self.cap.release()
        self.wait()


class WebcamDialog(QDialog):
    frame_captured = pyqtSignal(np.ndarray)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Live Face Capture")
        self.resize(700, 520)
        self.setStyleSheet("""
            QDialog { background-color: #0d1117; }
            QLabel { color: #e6edf3; font-size: 13px; }
            QPushButton {
                background-color: #21262d; color: #c9d1d9; border-radius: 5px;
                padding: 9px 18px; font-weight: 600; font-size: 13px;
                border: 1px solid #30363d;
            }
            QPushButton:hover { background-color: #30363d; color: #e6edf3; border: 1px solid #8b949e; }
        """)
        lay = QVBoxLayout(self)
        lay.setSpacing(12)
        info = QLabel("Position your face in the frame.  Green box = face detected.")
        info.setStyleSheet("color:#8b949e; font-size:13px; padding:6px;")
        lay.addWidget(info)
        self.video_label = QLabel()
        self.video_label.setMinimumSize(640, 400)
        self.video_label.setStyleSheet("background:#161b22; border-radius:5px; border:1px solid #30363d;")
        lay.addWidget(self.video_label)
        row = QHBoxLayout()
        cap_btn = QPushButton("Capture Photo")
        cap_btn.setStyleSheet("""
            background-color: #1f6feb;
            color: #ffffff; font-weight: 600; border-radius: 5px; padding: 10px 24px; font-size: 13px;
            border: 1px solid #388bfd;
        """)
        cap_btn.clicked.connect(self._capture)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.reject)
        row.addWidget(cap_btn)
        row.addWidget(close_btn)
        lay.addLayout(row)
        self.thread = WebcamThread()
        self.thread.change_pixmap.connect(self._update)
        self.thread.start()
        self.current_frame = None

    def _update(self, frame):
        self.current_frame = frame.copy()
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        self.video_label.setPixmap(
            QPixmap.fromImage(QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)).scaled(
                self.video_label.size(), Qt.KeepAspectRatio
            )
        )

    def _capture(self):
        if self.current_frame is not None:
            self.frame_captured.emit(self.current_frame.copy())
            self.accept()

    def closeEvent(self, event):
        try:
            self.thread.stop()
        except Exception:
            pass
        event.accept()


class ComplianceReviewDialog(QDialog):
    """Compliance officer reviews a flagged customer and records a decision."""

    def __init__(self, parent=None, customer_name="", criminal_record=None, trust_score=0):
        super().__init__(parent)
        self.setWindowTitle("Compliance Review — Flagged Customer")
        self.setMinimumWidth(700)
        self.setMinimumHeight(600)
        self.result_data = {}
        self.setStyleSheet("""
            QDialog { background-color: #0d1117; }
            QLabel  { color: #e6edf3; font-size: 13px; }
            QLineEdit {
                background-color: #0d1117; border: 1px solid #30363d;
                border-radius: 5px; padding: 8px 12px;
                color: #e6edf3; font-size: 13px;
            }
            QLineEdit:focus { border: 1px solid #1f6feb; }
            QTextEdit {
                background-color: #0d1117; border: 1px solid #21262d;
                border-radius: 5px; color: #e6edf3; font-size: 13px;
                padding: 8px;
            }
            QComboBox {
                background-color: #21262d; border: 1px solid #30363d;
                border-radius: 5px; padding: 7px 12px;
                color: #e6edf3; font-size: 13px;
            }
            QComboBox QAbstractItemView {
                background-color: #161b22; color: #e6edf3;
                selection-background-color: #1f3c6e;
            }
            QPushButton {
                background-color: #21262d; color: #c9d1d9; border-radius: 5px;
                padding: 9px 18px; font-weight: 600; border: 1px solid #30363d;
            }
            QPushButton:hover { background-color: #30363d; color: #e6edf3; border: 1px solid #8b949e; }
        """)

        lay = QVBoxLayout(self)
        lay.setSpacing(12)
        lay.setContentsMargins(20, 20, 20, 20)

        # --- Header banner ---
        banner = QFrame()
        banner.setStyleSheet("""
            background-color: #160d0d;
            border-radius: 5px; border: 1px solid #da3633;
            padding: 12px;
        """)
        bl = QVBoxLayout(banner)
        bl.setSpacing(4)
        title_lbl = QLabel("FLAGGED CUSTOMER — COMPLIANCE REVIEW REQUIRED")
        title_lbl.setStyleSheet("color:#f85149; font-size:14px; font-weight:700;")
        sub_lbl = QLabel(
            f"Customer: <b>{customer_name}</b>   |   "
            f"Trust Score: <b>{trust_score}/100</b>"
        )
        sub_lbl.setStyleSheet("color:#8b949e; font-size:13px;")
        sub_lbl.setTextFormat(Qt.RichText)
        bl.addWidget(title_lbl)
        bl.addWidget(sub_lbl)
        lay.addWidget(banner)

        # --- Criminal record details ---
        cr_lbl = QLabel("Criminal Record on File:")
        cr_lbl.setStyleSheet("color:#e3b341; font-weight:600; font-size:13px; margin-top:6px;")
        lay.addWidget(cr_lbl)

        cr_box = QFrame()
        cr_box.setStyleSheet("""
            background-color: #0d1117;
            border: 1px solid #9e6a03;
            border-radius: 5px;
            padding: 12px;
        """)
        cr_lay = QVBoxLayout(cr_box)
        cr_lay.setSpacing(6)

        if criminal_record and criminal_record.get("has_criminal_record"):
            cr = criminal_record
            risk_color = "#f85149" if cr.get("risk_level") == "high" else "#e3b341"
            meta_lbl = QLabel(
                f"<b style='color:{risk_color};'>Risk Level: {cr.get('risk_level','').upper()}</b>"
                f"&nbsp;&nbsp;&nbsp;Status: <span style='color:#e6edf3;'>{cr.get('status','')}</span>"
                f"&nbsp;&nbsp;&nbsp;Last Updated: {cr.get('last_updated','N/A')}"
            )
            meta_lbl.setTextFormat(Qt.RichText)
            meta_lbl.setStyleSheet("color:#e6edf3; font-size:13px;")
            cr_lay.addWidget(meta_lbl)

            for i, crime in enumerate(cr.get("crimes", []), 1):
                status_color = "#f85149" if crime.get("status") == "convicted" else "#e3b341"
                crime_frame = QFrame()
                crime_frame.setStyleSheet("""
                    background-color: #0d1117;
                    border: 1px solid #6e4a02;
                    border-radius: 5px;
                    padding: 10px;
                """)
                cf_lay = QVBoxLayout(crime_frame)
                cf_lay.setSpacing(3)
                c_title = QLabel(
                    f"<b style='color:#f85149;'>#{i}  {crime.get('type','Unknown')}</b>"
                    f"  <span style='color:#484f58;'>({crime.get('date','N/A')})</span>"
                )
                c_title.setTextFormat(Qt.RichText)
                cf_lay.addWidget(c_title)
                c_desc = QLabel(crime.get("description", ""))
                c_desc.setWordWrap(True)
                c_desc.setStyleSheet("color:#8b949e; font-size:12px;")
                cf_lay.addWidget(c_desc)
                c_stat = QLabel(
                    f"Status: <b style='color:{status_color};'>{crime.get('status','').upper()}</b>"
                    f"  |  Penalty: <span style='color:#8b949e;'>{crime.get('penalty','N/A')}</span>"
                )
                c_stat.setTextFormat(Qt.RichText)
                c_stat.setStyleSheet("font-size:12px;")
                cf_lay.addWidget(c_stat)
                crime_frame.setLayout(cf_lay)
                cr_lay.addWidget(crime_frame)
        else:
            no_cr = QLabel("No detailed criminal record data available.")
            no_cr.setStyleSheet("color:#484f58; font-size:13px;")
            cr_lay.addWidget(no_cr)

        cr_box.setLayout(cr_lay)
        lay.addWidget(cr_box)

        # --- Decision section ---
        dec_lbl = QLabel("Compliance Officer Decision:")
        dec_lbl.setStyleSheet("color:#388bfd; font-weight:600; font-size:13px; margin-top:8px;")
        lay.addWidget(dec_lbl)

        action_lay = QHBoxLayout()
        act_label = QLabel("Action:")
        act_label.setStyleSheet("color:#e6edf3; min-width:90px;")
        action_lay.addWidget(act_label)
        from PyQt5.QtWidgets import QComboBox
        self.action_combo = QComboBox()
        self.action_combo.addItems([
            "REJECT — Block account opening",
            "ESCALATE — Send to branch manager",
            "INVESTIGATE — Request more documents",
            "REPORT_FIA — Report to Federal Investigation Agency",
            "HOLD — Pending further review",
        ])
        action_lay.addWidget(self.action_combo)
        lay.addLayout(action_lay)

        name_lay = QHBoxLayout()
        name_label = QLabel("Officer Name:")
        name_label.setStyleSheet("color:#e6edf3; min-width:90px;")
        name_lay.addWidget(name_label)
        self.officer_name = QLineEdit()
        self.officer_name.setPlaceholderText("Enter officer's full name")
        name_lay.addWidget(self.officer_name)
        lay.addLayout(name_lay)

        notes_lbl = QLabel("Review Notes:")
        notes_lbl.setStyleSheet("color:#e6edf3; font-size:13px;")
        lay.addWidget(notes_lbl)
        self.notes = QTextEdit()
        self.notes.setPlaceholderText("Enter compliance review comments, observations, or additional findings...")
        self.notes.setMinimumHeight(90)
        lay.addWidget(self.notes)

        btn_lay = QHBoxLayout()
        save_btn = QPushButton("Submit Compliance Report")
        save_btn.setStyleSheet("""
            background-color: #21262d;
            color: #f85149; font-weight: 600; font-size: 13px;
            border-radius: 5px; padding: 10px 22px; border: 1px solid #da3633;
        """)
        save_btn.clicked.connect(self._save)
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setStyleSheet("""
            background-color: #21262d; color: #8b949e;
            border: 1px solid #30363d; border-radius: 5px; padding: 10px 18px;
        """)
        cancel_btn.clicked.connect(self.reject)
        btn_lay.addWidget(save_btn)
        btn_lay.addWidget(cancel_btn)
        lay.addLayout(btn_lay)

    def _save(self):
        if not self.officer_name.text().strip():
            QMessageBox.warning(self, "Required", "Please enter the officer's name.")
            return
        action = self.action_combo.currentText()
        self.result_data = {
            "action": action.split(" — ")[0],
            "action_full": action,
            "officer_name": self.officer_name.text().strip(),
            "notes": self.notes.toPlainText().strip(),
            "timestamp": datetime.now().isoformat(),
        }
        self.accept()


class CnicDataDialog(QDialog):
    """Enter data from the physical identity card."""

    def __init__(self, parent=None, cnic=""):
        super().__init__(parent)
        self.setWindowTitle("Enter Identity Card Data")
        self.setMinimumWidth(440)
        self.result_data = {}
        self.setStyleSheet("""
            QDialog { background-color: #0d1117; }
            QLabel  { color: #e6edf3; font-size: 13px; }
            QLineEdit {
                background-color: #0d1117; border: 1px solid #30363d;
                border-radius: 5px; padding: 8px 12px;
                color: #e6edf3; font-size: 13px;
            }
            QLineEdit:focus { border: 1px solid #1f6feb; }
            QPushButton {
                background-color: #21262d; color: #c9d1d9; border-radius: 5px;
                padding: 9px 18px; font-weight: 600; font-size: 13px;
                border: 1px solid #30363d;
            }
            QPushButton:hover { background-color: #30363d; color: #e6edf3; border: 1px solid #8b949e; }
        """)
        lay = QVBoxLayout(self)
        lay.setSpacing(10)
        lay.setContentsMargins(20, 20, 20, 20)

        title = QLabel("Enter details from the identity card:")
        title.setStyleSheet("color:#388bfd; font-weight:600; font-size:14px; margin-bottom:6px;")
        lay.addWidget(title)

        self.cnic = QLineEdit(normalize_cnic_entered(cnic) if cnic else "")
        self.cnic.setPlaceholderText("CNIC Number  (e.g. 12345-1234567-1)")
        self.name = QLineEdit()
        self.name.setPlaceholderText("Full Name")
        self.father = QLineEdit()
        self.father.setPlaceholderText("Father's Name")
        self.dob = QLineEdit()
        self.dob.setPlaceholderText("Date of Birth  (DD/MM/YYYY)")
        self.address = QLineEdit()
        self.address.setPlaceholderText("Address (from back of card)")

        for label, w in [
            ("CNIC Number", self.cnic),
            ("Full Name", self.name),
            ("Father's Name", self.father),
            ("Date of Birth", self.dob),
            ("Address", self.address),
        ]:
            lbl = QLabel(label)
            lbl.setStyleSheet("color:#8b949e; font-size:12px; margin-top:4px;")
            lay.addWidget(lbl)
            lay.addWidget(w)

        ok = QPushButton("Confirm Data")
        ok.setStyleSheet("""
            background-color: #1f6feb;
            color: #ffffff; font-weight: 600; border-radius: 5px; padding: 10px;
            font-size: 13px; margin-top:8px; border: 1px solid #388bfd;
        """)
        ok.clicked.connect(self._ok)
        lay.addWidget(ok)

    def _ok(self):
        cnic = normalize_cnic_entered(self.cnic.text().strip())
        name = self.name.text().strip()
        if len(re.sub(r"\D", "", cnic)) != 13:
            QMessageBox.warning(self, "Invalid CNIC", "Please enter a valid 13-digit CNIC (e.g. 12345-1234567-1).")
            return
        if not is_valid_person_name(name):
            QMessageBox.warning(self, "Invalid Name", "Please enter a valid full name (letters only).")
            return
        self.result_data = {
            "cnic": cnic,
            "name": name,
            "father_name": self.father.text().strip(),
            "date_of_birth": self.dob.text().strip(),
            "address": self.address.text().strip(),
        }
        self.accept()


class VerificationWorker(QThread):
    progress = pyqtSignal(int)
    result = pyqtSignal(dict)
    step = pyqtSignal(str)

    def __init__(self, cnic, face_img, doc_img, manual_data):
        super().__init__()
        self.cnic = cnic
        self.face_img = face_img
        self.doc_img = doc_img
        self.manual_data = manual_data or {}

    def run(self):
        results = {}
        self.step.emit("Identity input received — starting verification pipeline...")
        self.progress.emit(15)

        self.step.emit("Biometric processing: grayscale conversion, edge detection, face analysis...")
        face_score, liveness = 0.0, 0.0
        if self.face_img is not None:
            gray = cv2.cvtColor(self.face_img, cv2.COLOR_BGR2GRAY)
            blur = cv2.GaussianBlur(gray, (5, 5), 0)
            cv2.Canny(blur, 50, 150)
            fr = run_face_verification(self.face_img)
            face_score = fr.get("confidence", 0.8)
            liveness = fr.get("liveness_score", 0.75)
            _, n = FaceDetector.detect(self.face_img)
            self.step.emit(f"  Faces detected: {n}  |  Biometric score: {int(face_score * 100)}%  |  Liveness: {int(liveness * 100)}%")
        else:
            self.step.emit("  No face image provided.")
        self.progress.emit(40)

        self.step.emit("Document verification: authenticity analysis in progress...")
        doc_score = 0.0
        if self.doc_img is not None:
            doc = analyze_document(self.doc_img)
            doc_score = doc.get("authenticity_score", 0.85)
            self.step.emit(f"  Document authenticity score: {int(doc_score * 100)}%")
        self.progress.emit(55)

        self.step.emit("Criminal & AML database screening...")
        profile = get_customer_profile(self.cnic)
        results["criminal_record"] = profile["criminal_record"]
        results["profile"] = profile
        if profile["found_in_database"]:
            self.step.emit(f"  Customer on record: {profile['citizen'].get('name', '')}")
        else:
            self.step.emit("  New customer — not in existing records.")
        if profile["criminal_record"].get("has_criminal_record"):
            self.step.emit("  [ALERT]  CRIMINAL RECORD FOUND — flagging for compliance review")
        else:
            self.step.emit("  ✔  Criminal record: CLEAR")
        self.progress.emit(70)

        self.step.emit("Calculating trust score and risk assessment...")
        trust = calculate_trust_score(face_score, doc_score, 0.75)
        if profile["criminal_record"].get("has_criminal_record"):
            trust = max(0, trust - 40)
        if profile["decision"]["status"] == "REJECT":
            trust = max(0, trust - 25)
        bank = bank_record_for_cnic(self.cnic)
        entered_name = self.manual_data.get("name", "")
        is_correct = True
        if bank and entered_name:
            from difflib import SequenceMatcher
            sim = SequenceMatcher(
                None, entered_name.lower(), bank.get("name", "").lower()
            ).ratio()
            is_correct = sim >= 0.45
            if not is_correct:
                trust = max(0, trust - 35)
                self.step.emit("  Name does not match existing bank record — score penalty applied.")
            else:
                self.step.emit("  Name matches bank record.")
        results["trust_score"] = trust
        results["face_score"] = int(face_score * 100)
        results["doc_score"] = int(doc_score * 100)
        results["sig_score"] = 0
        results["is_correct_person"] = is_correct
        results["is_verified"] = profile["found_in_database"]
        results["risk_level"], results["risk_message"] = get_risk_level(trust)
        results["flags"] = generate_flags(face_score, doc_score, 0.75)
        risk_color_tag = "HIGH" if trust < 40 else ("MEDIUM" if trust < 70 else "LOW")
        self.step.emit(f"  Trust Score: {trust}/100  |  Risk: {risk_color_tag}")
        self.progress.emit(100)
        self.result.emit(results)


class KYCApplication(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CipherPass — Encrypted Identity Clearance & Intelligence Platform")
        self.setGeometry(40, 40, 1280, 800)
        self.setMinimumSize(1100, 720)
        self.face_img = None
        self.cnic_front_raw = None
        self.cnic_back_raw = None
        self.cnic_front_enh = None
        self.cnic_back_enh = None
        self.doc_img = None
        self.last_results = None
        self.last_manual = None
        self.last_compliance = None
        self._build_ui()
        self._update_dashboard()

    def _load_dashboard_stats(self):
        """Read verification history files and compute today's live stats."""
        today = datetime.now().strftime("%Y-%m-%d")
        total = flagged = cleared = high_risk = compliance_actions = 0
        hist_dir = Path("verification_data")
        if hist_dir.exists():
            for f in hist_dir.glob("*.json"):
                if f.name == "compliance_decisions.json":
                    try:
                        data = json.loads(f.read_text(encoding="utf-8"))
                        for d in data.get("decisions", []):
                            if d.get("timestamp", "").startswith(today):
                                compliance_actions += 1
                    except Exception:
                        pass
                    continue
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                    for session in data.get("sessions", []):
                        if session.get("timestamp", "").startswith(today):
                            total += 1
                            cr = session.get("criminal_record", {})
                            if cr.get("has_criminal_record"):
                                flagged += 1
                            trust = session.get("trust_score", 0) or 0
                            if trust >= 70:
                                cleared += 1
                            if session.get("risk_level", "") == "high":
                                high_risk += 1
                except Exception:
                    pass
        rate = int((cleared / total * 100)) if total > 0 else 0
        return {
            "total": total,
            "flagged": flagged,
            "cleared": cleared,
            "high_risk": high_risk,
            "clearance_rate": rate,
            "compliance_actions": compliance_actions,
        }

    def _update_dashboard(self):
        """Refresh all stat counter labels from live data."""
        s = self._load_dashboard_stats()
        self.stat_total.setText(str(s["total"]))
        self.stat_cleared.setText(str(s["cleared"]))
        self.stat_flagged.setText(str(s["flagged"]))
        self.stat_highrisk.setText(str(s["high_risk"]))
        self.stat_rate.setText(f"{s['clearance_rate']}%")
        self.stat_actions.setText(str(s["compliance_actions"]))

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setSpacing(6)
        root.setContentsMargins(10, 10, 10, 10)

        # ── Header ──────────────────────────────────────────────────────────
        header = QFrame()
        header.setStyleSheet(HEADER_STYLE)
        header.setFixedHeight(56)
        hl = QHBoxLayout(header)
        hl.setContentsMargins(18, 0, 18, 0)

        # Brand
        brand_row = QHBoxLayout()
        brand_row.setSpacing(10)
        brand_lbl = QLabel("CipherPass")
        brand_lbl.setStyleSheet(
            "color:#e6edf3; font-size:18px; font-weight:700; letter-spacing:0px;"
        )
        ver_lbl = QLabel("v2.0")
        ver_lbl.setStyleSheet(
            "color:#484f58; font-size:10px; font-weight:600; padding-top:5px;"
        )
        sep_lbl = QLabel("|")
        sep_lbl.setStyleSheet("color:#21262d; font-size:16px; padding-top:2px;")
        tag_lbl = QLabel(APP_TAGLINE)
        tag_lbl.setStyleSheet(
            "color:#484f58; font-size:11px;"
        )
        brand_row.addWidget(brand_lbl)
        brand_row.addWidget(ver_lbl)
        brand_row.addWidget(sep_lbl)
        brand_row.addWidget(tag_lbl)
        brand_row.addStretch()
        hl.addLayout(brand_row)

        # Module tags (plain text, no emoji)
        badge_row = QHBoxLayout()
        badge_row.setSpacing(6)
        for text in ["Biometrics", "Intelligence", "AML Shield"]:
            b = QLabel(text)
            b.setStyleSheet(
                "background-color:#21262d; color:#8b949e; border-radius:4px;"
                " padding:3px 10px; font-size:10px; font-weight:600;"
                " border: 1px solid #30363d;"
            )
            badge_row.addWidget(b)
        hl.addLayout(badge_row)
        root.addWidget(header)

        # ── Live Dashboard Stats Bar ─────────────────────────────────────────
        dash = QFrame()
        dash.setStyleSheet(
            "background-color:#161b22; border:1px solid #21262d;"
            " border-radius:5px;"
        )
        dash.setFixedHeight(48)
        dash_lay = QHBoxLayout(dash)
        dash_lay.setSpacing(0)
        dash_lay.setContentsMargins(8, 4, 8, 4)

        stat_defs = [
            ("Verifications", "0",  "#388bfd", "stat_total"),
            ("Cleared",       "0",  "#3fb950", "stat_cleared"),
            ("Flagged",       "0",  "#f85149", "stat_flagged"),
            ("High Risk",     "0",  "#e3b341", "stat_highrisk"),
            ("Clear Rate",    "0%", "#58a6ff", "stat_rate"),
            ("Compliance",    "0",  "#8b949e", "stat_actions"),
        ]
        for i, (label, val, color, attr) in enumerate(stat_defs):
            if i > 0:
                sep = QFrame()
                sep.setFrameShape(QFrame.VLine)
                sep.setStyleSheet("background:#21262d; max-width:1px; margin:4px 0;")
                dash_lay.addWidget(sep)
            card = QWidget()
            cl = QHBoxLayout(card)
            cl.setSpacing(6)
            cl.setContentsMargins(12, 2, 12, 2)
            count_lbl = QLabel(val)
            count_lbl.setStyleSheet(f"color:{color}; font-size:17px; font-weight:700;")
            label_lbl = QLabel(label)
            label_lbl.setStyleSheet("color:#484f58; font-size:10px; font-weight:600;")
            cl.addWidget(count_lbl)
            cl.addWidget(label_lbl)
            setattr(self, attr, count_lbl)
            dash_lay.addWidget(card)

        dash_lay.addStretch()
        refresh_btn = QPushButton("Refresh")
        refresh_btn.setToolTip("Refresh dashboard stats")
        refresh_btn.setFixedHeight(26)
        refresh_btn.setStyleSheet(
            "background:#21262d; color:#8b949e; border-radius:4px;"
            " font-size:10px; font-weight:600; border:1px solid #30363d;"
            " padding:0 10px;"
        )
        refresh_btn.clicked.connect(self._update_dashboard)
        dash_lay.addWidget(refresh_btn)
        root.addWidget(dash)

        # ── Main content — QSplitter (resizable panels) ──────────────────────
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(1)
        splitter.setStyleSheet(
            "QSplitter::handle { background:#21262d; }"
            "QSplitter::handle:hover { background:#1f6feb; }"
        )

        # ── LEFT PANEL ──────────────────────────────────────────────────────
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.NoFrame)
        left_w = QWidget()
        left_lay = QVBoxLayout(left_w)
        left_lay.setSpacing(7)
        left_lay.setContentsMargins(0, 2, 4, 2)

        # Step 1 — Upload ID Card
        g1 = QGroupBox("Step 1 — Upload Identity Card (CNIC)")
        g1l = QVBoxLayout(g1)
        g1l.setSpacing(6)
        upload_row = QHBoxLayout()
        b1 = QPushButton("Upload Front Side")
        b1.clicked.connect(self._upload_front)
        b2 = QPushButton("Upload Back Side")
        b2.clicked.connect(self._upload_back)
        upload_row.addWidget(b1)
        upload_row.addWidget(b2)
        g1l.addLayout(upload_row)

        self.prev_front = QLabel("Front — not uploaded")
        self.prev_back = QLabel("Back — not uploaded")
        for p, tip in ((self.prev_front, "CNIC Front"), (self.prev_back, "CNIC Back")):
            p.setFixedSize(148, 100)
            p.setAlignment(Qt.AlignCenter)
            p.setToolTip(tip)
            p.setStyleSheet(
                "background:#161b22; border:1px dashed #30363d;"
                " border-radius:5px; color:#484f58; font-size:11px;"
            )
        pr = QHBoxLayout()
        pr.addWidget(self.prev_front)
        pr.addWidget(self.prev_back)
        g1l.addLayout(pr)

        dip_b = QPushButton("View Processing Steps")
        dip_b.setStyleSheet(
            "background:#21262d; color:#8b949e; border:1px solid #30363d;"
            " border-radius:5px; padding:7px; font-size:11px; font-weight:600;"
        )
        dip_b.clicked.connect(self._show_dip)
        g1l.addWidget(dip_b)
        left_lay.addWidget(g1)

        # Step 2 — Customer Data
        g2 = QGroupBox("Step 2 — Customer Information")
        g2l = QVBoxLayout(g2)
        g2l.setSpacing(4)
        self.cnic_in  = self._field(g2l, "CNIC Number",    "42101-1234567-1")
        self.name_in  = self._field(g2l, "Full Name",       "Enter full name")
        self.father_in = self._field(g2l, "Father's Name",  "Enter father's name")
        self.dob_in   = self._field(g2l, "Date of Birth",   "DD/MM/YYYY")
        self.addr_in  = self._field(g2l, "Address",         "Enter address")

        btn_row1 = QHBoxLayout()
        enter_b = QPushButton("Enter from Card")
        enter_b.setStyleSheet(BTN_SUCCESS)
        enter_b.clicked.connect(self._enter_cnic_dialog)
        load_b = QPushButton("Load Demo")
        load_b.setStyleSheet(BTN_WARNING)
        load_b.clicked.connect(self._load_bank)
        btn_row1.addWidget(enter_b)
        btn_row1.addWidget(load_b)
        g2l.addLayout(btn_row1)

        btn_row2 = QHBoxLayout()
        lookup_b = QPushButton("Lookup Profile")
        lookup_b.setStyleSheet(BTN_PRIMARY)
        lookup_b.clicked.connect(self._lookup_profile)
        save_b = QPushButton("Save Data")
        save_b.clicked.connect(self._save)
        btn_row2.addWidget(lookup_b)
        btn_row2.addWidget(save_b)
        g2l.addLayout(btn_row2)

        self.hint = QLabel(
            "Demo CNICs:  42101-1234567-1 (clean)  ·  12345-6789012-3 (flagged)"
        )
        self.hint.setWordWrap(True)
        self.hint.setStyleSheet(
            "color:#484f58; font-size:10px; padding:4px 0; font-style:italic;"
        )
        g2l.addWidget(self.hint)
        left_lay.addWidget(g2)

        # Step 3 — Face Capture
        g3 = QGroupBox("Step 3 — Biometric Face Capture")
        g3l = QHBoxLayout(g3)
        g3l.setSpacing(10)

        face_btn_col = QVBoxLayout()
        fb = QPushButton("Open Camera")
        fb.setStyleSheet(BTN_PRIMARY)
        fb.clicked.connect(self._capture_face)
        face_info = QLabel(
            "Live face capture with\ngreen detection box.\nPositon face in frame."
        )
        face_info.setStyleSheet("color:#484f58; font-size:10px; line-height:1.4;")
        face_btn_col.addWidget(fb)
        face_btn_col.addWidget(face_info)
        face_btn_col.addStretch()
        g3l.addLayout(face_btn_col)

        self.face_prev = QLabel("No face\ncaptured")
        self.face_prev.setFixedSize(120, 120)
        self.face_prev.setAlignment(Qt.AlignCenter)
        self.face_prev.setStyleSheet(
            "background:#161b22; border:1px dashed #30363d;"
            " border-radius:5px; color:#484f58; font-size:11px;"
        )
        g3l.addWidget(self.face_prev)
        left_lay.addWidget(g3)

        # Verify button
        self.verify_b = QPushButton("START VERIFICATION")
        self.verify_b.setStyleSheet(BTN_VERIFY)
        self.verify_b.setMinimumHeight(44)
        self.verify_b.clicked.connect(self._verify)
        left_lay.addWidget(self.verify_b)
        left_lay.addStretch()

        left_scroll.setWidget(left_w)
        splitter.addWidget(left_scroll)

        # ── RIGHT PANEL ──────────────────────────────────────────────────────
        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setFrameShape(QFrame.NoFrame)
        rw = QWidget()
        rl = QVBoxLayout(rw)
        rl.setSpacing(7)
        rl.setContentsMargins(4, 2, 0, 2)

        # Score + status strip
        score_strip = QFrame()
        score_strip.setStyleSheet(
            "background-color: #161b22;"
            " border:1px solid #21262d; border-top: 2px solid #1f6feb; border-radius:6px;"
        )
        ss_lay = QHBoxLayout(score_strip)
        ss_lay.setContentsMargins(16, 12, 16, 12)
        ss_lay.setSpacing(16)

        # Big score number
        score_col = QVBoxLayout()
        score_col.setSpacing(2)
        score_title = QLabel("TRUST SCORE")
        score_title.setStyleSheet(
            "color:#484f58; font-size:9px; font-weight:700; letter-spacing:2px;"
        )
        self.score_lbl = QLabel("—")
        self.score_lbl.setStyleSheet(
            "font-size:48px; font-weight:900; color:#10b981; line-height:1;"
        )
        self.risk_lbl = QLabel("Awaiting verification...")
        self.risk_lbl.setStyleSheet("color:#484f58; font-size:11px; font-weight:600;")
        score_col.addWidget(score_title)
        score_col.addWidget(self.score_lbl)
        score_col.addWidget(self.risk_lbl)
        ss_lay.addLayout(score_col)

        # Divider
        vline = QFrame()
        vline.setFrameShape(QFrame.VLine)
        vline.setStyleSheet("background:#21262d; max-width:1px;")
        ss_lay.addWidget(vline)

        # Status indicators
        status_col = QVBoxLayout()
        status_col.setSpacing(6)

        def _make_status_card(title, attr):
            card = QFrame()
            card.setStyleSheet(
                "background:#0d1117; border:1px solid #21262d;"
                " border-radius:5px; padding:2px;"
            )
            cl = QHBoxLayout(card)
            cl.setContentsMargins(10, 6, 10, 6)
            cl.setSpacing(8)
            title_lbl = QLabel(title)
            title_lbl.setStyleSheet(
                "color:#484f58; font-size:10px; font-weight:600;"
                " min-width:90px;"
            )
            val_lbl = QLabel("—")
            val_lbl.setStyleSheet("color:#484f58; font-size:11px; font-weight:600;")
            cl.addWidget(title_lbl)
            cl.addWidget(val_lbl)
            setattr(self, attr, val_lbl)
            return card

        status_col.addWidget(_make_status_card("Identity Match",        "person_lbl"))
        status_col.addWidget(_make_status_card("Criminal Record",       "crim_lbl"))
        status_col.addWidget(_make_status_card("Prev. Verifications",   "prev_verif_lbl"))
        ss_lay.addLayout(status_col)
        ss_lay.addStretch()

        # Score progress bar (visual only)
        self.score_bar = QProgressBar()
        self.score_bar.setRange(0, 100)
        self.score_bar.setValue(0)
        self.score_bar.setTextVisible(False)
        self.score_bar.setFixedHeight(6)
        self.score_bar.setStyleSheet("""
            QProgressBar {
                background:#21262d; border:none; border-radius:3px;
            }
            QProgressBar::chunk {
                background-color: #1f6feb;
                border-radius:3px;
            }
        """)

        score_outer = QVBoxLayout()
        score_outer.setSpacing(4)
        score_outer.addWidget(score_strip)
        score_outer.addWidget(self.score_bar)
        rl.addLayout(score_outer)

        # Action buttons row
        action_row = QHBoxLayout()
        self.export_btn = QPushButton("Export PDF Report")
        self.export_btn.setStyleSheet("""
            background-color: #21262d;
            color:#c9d1d9; font-weight:600; font-size:11px;
            border-radius:5px; padding:8px 14px; border:1px solid #388bfd;
        """)
        self.export_btn.clicked.connect(self._export_pdf)
        self.export_btn.setVisible(False)

        self.dip_btn = QPushButton("DIP Processing Steps")
        self.dip_btn.setStyleSheet("""
            background-color: #21262d;
            color:#8b949e; font-weight:600; font-size:11px;
            border-radius:5px; padding:8px 14px; border:1px solid #30363d;
        """)
        self.dip_btn.clicked.connect(self._show_dip_showcase)
        self.dip_btn.setVisible(False)

        action_row.addWidget(self.export_btn)
        action_row.addWidget(self.dip_btn)
        rl.addLayout(action_row)

        # Recent Verifications
        recent_hdr = QHBoxLayout()
        recent_title = QLabel("RECENT VERIFICATIONS")
        recent_title.setStyleSheet(
            "color:#484f58; font-size:9px; font-weight:700; letter-spacing:1.5px;"
        )
        recent_hdr.addWidget(recent_title)
        recent_hdr.addStretch()
        rl.addLayout(recent_hdr)

        self.recent_list = QTextEdit()
        self.recent_list.setReadOnly(True)
        self.recent_list.setFixedHeight(130)
        self.recent_list.setStyleSheet(
            "background:#0d1117; border:1px solid #21262d;"
            " border-radius:5px; color:#e6edf3; font-size:11px; padding:4px;"
        )
        rl.addWidget(self.recent_list)
        self._refresh_recent_verifications()

        # Activity log
        log_hdr = QHBoxLayout()
        log_title = QLabel("ACTIVITY LOG")
        log_title.setStyleSheet(
            "color:#484f58; font-size:9px; font-weight:700; letter-spacing:1.5px;"
        )
        log_hdr.addWidget(log_title)
        log_hdr.addStretch()
        rl.addLayout(log_hdr)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        rl.addWidget(self.log)

        right_scroll.setWidget(rw)
        splitter.addWidget(right_scroll)

        # Set initial split sizes (left ~420, right takes remaining)
        splitter.setSizes([420, 860])
        root.addWidget(splitter, 1)

        # ── Progress bar (bottom) ────────────────────────────────────────────
        self.prog = QProgressBar()
        self.prog.setVisible(False)
        self.prog.setFixedHeight(14)
        self.prog.setTextVisible(True)
        root.addWidget(self.prog)

        self.setStyleSheet(APP_STYLESHEET)

    def _field(self, layout, label, ph):
        lbl = QLabel(label)
        lbl.setStyleSheet("color:#8b949e; font-size:11px; margin-top:3px; font-weight:500;")
        layout.addWidget(lbl)
        w = QLineEdit()
        w.setPlaceholderText(ph)
        layout.addWidget(w)
        return w

    def _read_img(self, path):
        img = cv2.imread(path)
        if img is None:
            img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
        try:
            from PIL import Image, ExifTags
            pil = Image.open(path)
            exif = pil._getexif()
            orientation = None
            if exif is not None:
                for k, v in ExifTags.TAGS.items():
                    if v == 'Orientation':
                        orientation = exif.get(k)
                        break
            if orientation is not None and img is not None:
                if orientation == 3:
                    img = cv2.rotate(img, cv2.ROTATE_180)
                elif orientation == 6:
                    img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
                elif orientation == 8:
                    img = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        except Exception:
            pass
        return img

    def _upload_front(self):
        path, _ = QFileDialog.getOpenFileName(self, "Upload CNIC Front", "", "Images (*.png *.jpg *.jpeg)")
        if not path:
            return
        self.cnic_front_raw = self._read_img(path)
        if self.cnic_front_raw is None:
            QMessageBox.warning(self, "Error", "Cannot read the selected image.")
            return
        self.cnic_front_enh = enhance_cnic_image(self.cnic_front_raw)
        self.doc_img = self.cnic_front_enh
        self.prev_front.setPixmap(numpy_to_pixmap(self.cnic_front_enh, 130, 95))
        log_message(self.log, "CNIC front uploaded and enhanced successfully.", "success")
        self._enter_cnic_dialog()

    def _upload_back(self):
        path, _ = QFileDialog.getOpenFileName(self, "Upload CNIC Back", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            self.cnic_back_raw = self._read_img(path)
            if self.cnic_back_raw is not None:
                self.cnic_back_enh = enhance_cnic_image(self.cnic_back_raw)
                self.prev_back.setPixmap(
                    numpy_to_pixmap(self.cnic_back_enh, 130, 95)
                )
                log_message(self.log, "CNIC back uploaded and enhanced.", "success")

    def _enter_cnic_dialog(self):
        dlg = CnicDataDialog(self, self.cnic_in.text())
        if dlg.exec_() == QDialog.Accepted:
            d = dlg.result_data
            self.cnic_in.setText(d["cnic"])
            self.name_in.setText(d["name"])
            self.father_in.setText(d.get("father_name", ""))
            self.dob_in.setText(d.get("date_of_birth", ""))
            self.addr_in.setText(d.get("address", ""))
            log_message(self.log, f"Customer data entered: {d['name']}", "success")

    def _load_bank(self):
        cnic = self.cnic_in.text().strip()
        if not cnic:
            QMessageBox.warning(self, "CNIC Required", "Please enter a CNIC number first.")
            return
        p = get_customer_profile(cnic)
        if not p["found_in_database"]:
            QMessageBox.information(self, "Not Found", "CNIC not found in demo database.")
            return
        c = p["citizen"]
        self.cnic_in.setText(normalize_cnic_entered(c.get("cnic", cnic)))
        self.name_in.setText(c.get("name", ""))
        self.father_in.setText(c.get("father") or c.get("father_name", ""))
        self.dob_in.setText(c.get("dob", ""))
        self.addr_in.setText(c.get("address", ""))
        self.hint.setText(f"Loaded: {c.get('name')}  |  AML Status: {p['decision']['status']}")
        log_message(self.log, f"Loaded record from database: {c.get('name')}", "success")

    def _lookup_profile(self):
        cnic = self.cnic_in.text().strip()
        if not cnic:
            QMessageBox.warning(self, "CNIC Required", "Please enter a CNIC number first.")
            return
        profile = get_customer_profile(cnic)
        profile_text = [
            f"CNIC: {profile['cnic']}",
            f"Bank Record: {'FOUND' if profile['found_in_database'] else 'NOT FOUND'}",
            f"Criminal Record: {'FLAGGED' if profile['criminal_record'].get('has_criminal_record') else 'CLEAR'}",
            f"Decision: {profile['decision']['status']}",
            f"Reason: {profile['decision']['reason']}",
            f"Previous Checks: {profile['previous_count']}",
        ]
        if profile['found_in_database']:
            citizen = profile['citizen']
            profile_text.insert(1, f"Name: {citizen.get('name', 'N/A')}")
            profile_text.insert(2, f"Father: {citizen.get('father') or citizen.get('father_name', 'N/A')}")
        if profile['criminal_record'].get('has_criminal_record'):
            profile_text.append("")
            profile_text.append("Crimes on Record:")
            for crime in profile['criminal_record'].get('crimes', []):
                profile_text.append(f"  ▸ {crime.get('type')} ({crime.get('date')})")
                profile_text.append(f"    {crime.get('description', '')}")
        QMessageBox.information(self, "Customer Profile", "\n".join(profile_text))
        log_message(self.log, f"Profile lookup complete: {profile['decision']['status']}", "success")

    def _save(self):
        if self.cnic_front_raw is None:
            QMessageBox.warning(self, "Upload Required", "Please upload the CNIC front image first.")
            return
        manual = {
            "cnic": normalize_cnic_entered(self.cnic_in.text()),
            "name": self.name_in.text().strip(),
            "father_name": self.father_in.text().strip(),
            "date_of_birth": self.dob_in.text().strip(),
            "address": self.addr_in.text().strip(),
        }
        ok, msg = validate_pakistan_cnic(manual["cnic"])
        if not ok:
            QMessageBox.warning(self, "Invalid CNIC", msg)
            return
        if not is_valid_person_name(manual["name"]):
            QMessageBox.warning(self, "Invalid Name", "Please enter a valid full name.")
            return
        self.cnic_front_enh = enhance_cnic_image(self.cnic_front_raw)
        folder = save_cnic_archive(
            manual["cnic"], self.cnic_front_raw, self.cnic_front_enh,
            self.cnic_back_raw, None, manual,
            face_img=self.face_img,
            doc_img=self.doc_img,
        )
        OFFICIAL_DATABASE[manual["cnic"]] = {
            **manual,
            "father": manual["father_name"],
            "dob": manual["date_of_birth"],
            "trust_score": 85,
        }
        with open(DATABASE_FILE, "w", encoding="utf-8") as f:
            json.dump(OFFICIAL_DATABASE, f, indent=2)
        QMessageBox.information(self, "Saved Successfully", f"Customer record saved to:\n{folder}")
        log_message(self.log, f"Customer saved: {manual['name']}", "success")

    def _capture_face(self):
        d = WebcamDialog(self)
        d.frame_captured.connect(self._on_face)
        d.exec_()

    def _archive_verification(self, manual: dict, results: dict):
        archive_folder = save_cnic_archive(
            manual["cnic"], self.cnic_front_raw, self.cnic_front_enh,
            self.cnic_back_raw, None, manual,
            face_img=self.face_img,
            doc_img=self.doc_img,
        )
        session = {
            "timestamp": datetime.now().isoformat(),
            "cnic": normalize_cnic(manual["cnic"]),
            "manual_data": manual,
            "trust_score": results.get("trust_score"),
            "risk_level": results.get("risk_level"),
            "is_correct_person": results.get("is_correct_person"),
            "is_verified": results.get("is_verified"),
            "criminal_record": results.get("criminal_record"),
            "flags": results.get("flags"),
            "archive_folder": archive_folder,
        }
        save_verification_history(manual["cnic"], session)
        log_message(self.log, f"Verification archived: {archive_folder}", "success")

    def _save_compliance_decision(self, manual: dict, compliance_decision: dict, results: dict):
        compliance_file = Path("verification_data") / "compliance_decisions.json"
        Path("verification_data").mkdir(parents=True, exist_ok=True)
        decisions = {"decisions": []}
        if compliance_file.exists():
            with open(compliance_file, "r", encoding="utf-8") as f:
                try:
                    decisions = json.load(f)
                except json.JSONDecodeError:
                    decisions = {"decisions": []}
        decision_record = {
            "timestamp": compliance_decision["timestamp"],
            "cnic": normalize_cnic(manual["cnic"]),
            "customer_name": manual.get("name"),
            "action": compliance_decision["action"],
            "officer_name": compliance_decision["officer_name"],
            "notes": compliance_decision["notes"],
            "trust_score": results.get("trust_score"),
            "criminal_record": results.get("criminal_record"),
        }
        decisions["decisions"].append(decision_record)
        with open(compliance_file, "w", encoding="utf-8") as f:
            json.dump(decisions, f, indent=2)
        log_message(self.log, "Compliance decision archived to records.", "success")

    def _refresh_recent_verifications(self):
        """Load last 6 verifications from history and display them in the recent panel."""
        all_sessions = []
        hist_dir = Path("verification_data")
        if hist_dir.exists():
            for f in hist_dir.glob("*.json"):
                if f.name == "compliance_decisions.json":
                    continue
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                    for s in data.get("sessions", []):
                        all_sessions.append(s)
                except Exception:
                    pass
        all_sessions.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        recent = all_sessions[:6]
        if not recent:
            self.recent_list.setHtml(
                "<div style='color:#484f58; padding:10px; font-size:12px;'>"
                "No verifications on record yet.</div>"
            )
            return
        html = ""
        for s in recent:
            ts = s.get("timestamp", "")[:16].replace("T", " ")
            name = s.get("manual_data", {}).get("name", "Unknown")
            cnic = s.get("cnic", "")
            trust = s.get("trust_score", 0) or 0
            risk = s.get("risk_level", "unknown")
            has_cr = s.get("criminal_record", {}).get("has_criminal_record", False)
            t_color = "#3fb950" if trust >= 70 else ("#e3b341" if trust >= 40 else "#f85149")
            cr_badge = (
                "<span style='background:#1a0a0a;color:#f85149;border-radius:3px;"
                "padding:1px 6px;font-size:10px;border:1px solid #da3633;'>FLAGGED</span>"
                if has_cr else
                "<span style='background:#0d1f17;color:#3fb950;border-radius:3px;"
                "padding:1px 6px;font-size:10px;border:1px solid #238636;'>CLEAR</span>"
            )
            html += (
                f"<div style='padding:5px 8px; border-bottom:1px solid #21262d;'>"
                f"<span style='color:#484f58;font-size:11px;'>{ts}</span>"
                f"&nbsp;&nbsp;<b style='color:#e6edf3;'>{name}</b>"
                f"&nbsp;<span style='color:#484f58;font-size:10px;'>{cnic}</span><br>"
                f"<span style='color:{t_color};font-weight:600;font-size:11px;'>"
                f"Trust: {trust}/100</span>&nbsp;&nbsp;{cr_badge}"
                f"</div>"
            )
        self.recent_list.setHtml(
            f"<div style='background:#0d1117; font-family: Segoe UI, Arial;'>{html}</div>"
        )

    def _show_dip_showcase(self):
        """Open the DIP Showcase dialog for the last processed image."""
        img = None
        label = "Input Image"
        if self.face_img is not None:
            img = self.face_img
            label = "Live Face Capture"
        elif self.cnic_front_enh is not None:
            img = self.cnic_front_enh
            label = "CNIC Front (Enhanced)"
        elif self.doc_img is not None:
            img = self.doc_img
            label = "Document Image"

        if img is None:
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.information(
                self, "No Image",
                "Capture a face or upload a CNIC first, then run verification to see DIP steps."
            )
            return

        dlg = DipShowcaseDialog(self, image=img, image_label=label)
        dlg.exec_()

    def _export_pdf(self):
        """Generate and save a PDF compliance report for the last verification."""
        if not self.last_results or not self.last_manual:
            QMessageBox.warning(self, "No Data", "Please run a verification first.")
            return
        log_message(self.log, "Generating PDF report...", "info")
        path = generate_pdf_report(self.last_manual, self.last_results, self.last_compliance)
        if path:
            QMessageBox.information(
                self,
                "✔  PDF Report Saved",
                f"Report saved to:\n{path}\n\n"
                f"File: CipherPass_Report_{self.last_manual.get('cnic','').replace('-','')}_..."
            )
            log_message(self.log, f"PDF report saved: {path}", "success")
        else:
            QMessageBox.warning(self, "Export Failed", "Could not generate PDF. Check reportlab is installed.")

    def _on_face(self, frame):
        self.face_img = frame
        self.face_prev.setPixmap(numpy_to_pixmap(frame, 160, 160))
        log_message(self.log, "Face captured successfully.", "success")

    def _show_dip(self):
        if self.cnic_front_enh is None:
            QMessageBox.warning(self, "No Front Image", "Please upload the CNIC front image first.")
            return
        if self.cnic_back_raw is None:
            QMessageBox.warning(self, "No Back Image", "Please upload the CNIC back image first.")
            return
        img = self.cnic_front_enh
        pipe = run_dip_pipeline(img)
        dlg = QDialog(self)
        dlg.setWindowTitle("Image Processing Pipeline")
        dlg.resize(960, 520)
        dlg.setStyleSheet("""
            QDialog { background-color: #0d1117; }
            QLabel  { color: #e6edf3; font-size: 12px; }
            QPushButton {
                background-color: #21262d; color: #c9d1d9; border-radius: 5px;
                padding: 8px 18px; font-weight: 600; border: 1px solid #30363d;
            }
            QPushButton:hover { background-color: #30363d; color: #e6edf3; }
        """)
        lay = QVBoxLayout(dlg)
        summary_lbl = QLabel(get_dip_summary())
        summary_lbl.setStyleSheet("color:#8b949e; font-size:13px; padding:8px 0;")
        lay.addWidget(summary_lbl)
        grid = QHBoxLayout()
        for step_img, label in zip(pipe["steps"], pipe["labels"]):
            col = QVBoxLayout()
            step_lbl = QLabel(label)
            step_lbl.setAlignment(Qt.AlignCenter)
            step_lbl.setStyleSheet(
                "color:#8b949e; font-size:11px; font-weight:600;"
                " background:#161b22; border-radius:4px; padding:4px;"
            )
            col.addWidget(step_lbl)
            pic = QLabel()
            pic.setPixmap(numpy_to_pixmap(step_img, 145, 105))
            pic.setStyleSheet("border:1px solid #30363d; border-radius:4px;")
            col.addWidget(pic)
            w = QWidget()
            w.setLayout(col)
            grid.addWidget(w)
        lay.addLayout(grid)
        close = QPushButton("Close")
        close.clicked.connect(dlg.accept)
        lay.addWidget(close)
        dlg.exec_()

    def _verify(self):
        cnic = self.cnic_in.text().strip()
        if not cnic or not is_valid_person_name(self.name_in.text()):
            QMessageBox.warning(self, "Missing Information", "Please enter CNIC and full name.")
            return
        if self.face_img is None:
            QMessageBox.warning(self, "Face Required", "Please capture a face photo first.")
            return
        if self.cnic_front_raw is None:
            QMessageBox.warning(self, "Document Required", "Please upload the CNIC front image first.")
            return

        pre_profile = get_customer_profile(cnic)
        if pre_profile["criminal_record"].get("has_criminal_record"):
            risk = pre_profile["criminal_record"].get("risk_level", "high")
            crimes = pre_profile["criminal_record"].get("crimes", [])
            crime_list = "\n".join([
                "  ▸ " + c.get("type", "Unknown") + " (" + c.get("date", "") + ")"
                for c in crimes
            ])
            msg = (
                "WARNING — This CNIC has a criminal record on file!\n\n"
                "Risk Level: " + risk.upper() + "\n"
                "Status: " + pre_profile["criminal_record"].get("status", "") + "\n\n"
                "Crimes on record:\n" + crime_list + "\n\n"
                "Proceeding to full verification and compliance review."
            )
            QMessageBox.warning(self, "WARNING — Criminal Record Detected", msg)

        prev_count = pre_profile.get("previous_count", 0)
        if prev_count >= 3:
            dup_msg = (
                "This CNIC has been verified " + str(prev_count) + " time(s) previously.\n\n"
                "Multiple verifications for the same CNIC may indicate:\n"
                "  ▸ Account takeover attempt\n"
                "  ▸ Identity theft\n"
                "  ▸ Repeat fraud attempt\n\n"
                "Proceeding with verification — compliance review recommended."
            )
            QMessageBox.warning(self, "WARNING — Duplicate Verification Alert", dup_msg)

        self.log.clear()
        self.prog.setVisible(True)
        self.verify_b.setEnabled(False)
        manual = {
            "cnic": cnic,
            "name": self.name_in.text().strip(),
            "father_name": self.father_in.text().strip(),
            "date_of_birth": self.dob_in.text().strip(),
            "address": self.addr_in.text().strip(),
        }
        self.current_manual = manual
        self.worker = VerificationWorker(cnic, self.face_img, self.doc_img, manual)
        self.worker.progress.connect(self.prog.setValue)
        self.worker.step.connect(lambda s: log_message(self.log, s, "info"))
        self.worker.result.connect(self._on_result)
        self.worker.start()

    def _on_result(self, r):
        self.prog.setVisible(False)
        self.verify_b.setEnabled(True)

        trust = r["trust_score"]
        color = "#10b981" if trust >= 70 else ("#f59e0b" if trust >= 40 else "#ef4444")

        self.score_lbl.setText(f"{trust}/100")
        self.score_lbl.setStyleSheet(f"font-size:48px; font-weight:900; color:{color}; line-height:1;")
        self.risk_lbl.setText(r["risk_level"].upper() + " RISK  —  " + r.get("risk_message", ""))
        self.risk_lbl.setStyleSheet(f"color:{color}; font-size:11px; font-weight:700;")
        self.score_bar.setValue(trust)

        self.person_lbl.setText(
            "✔  IDENTITY VERIFIED" if r.get("is_correct_person") else "✗  CHECK IDENTITY"
        )
        person_color = "#10b981" if r.get("is_correct_person") else "#ef4444"
        self.person_lbl.setStyleSheet(f"color:{person_color}; font-size:11px; font-weight:700;")

        cr = r.get("criminal_record", {})
        if cr.get("has_criminal_record"):
            self.crim_lbl.setText("CRIMINAL RECORD FOUND — " + cr.get("risk_level", "high").upper())
            self.crim_lbl.setStyleSheet("color:#ef4444; font-size:11px; font-weight:700;")
        else:
            self.crim_lbl.setText("✔  CLEAR — No Criminal Record")
            self.crim_lbl.setStyleSheet("color:#10b981; font-size:11px; font-weight:700;")

        profile = r.get("profile", {})
        prev_count = profile.get("previous_count", 0)
        if prev_count >= 3:
            self.prev_verif_lbl.setText(f"DUPLICATE ALERT — {prev_count} previous")
            self.prev_verif_lbl.setStyleSheet("color:#f59e0b; font-size:11px; font-weight:700;")
            log_message(
                self.log,
                f"DUPLICATE ALERT: CNIC verified {prev_count} times previously — possible fraud.",
                "warning"
            )
        elif prev_count > 0:
            self.prev_verif_lbl.setText(f"{prev_count} previous verification(s)")
            self.prev_verif_lbl.setStyleSheet("color:#f59e0b; font-size:11px; font-weight:700;")
        else:
            self.prev_verif_lbl.setText("✔  First-time verification")
            self.prev_verif_lbl.setStyleSheet("color:#10b981; font-size:11px; font-weight:700;")

        self._archive_verification(self.current_manual, r)

        # Store for PDF export
        self.last_results = r
        self.last_manual = self.current_manual
        self.last_compliance = None

        if cr.get("has_criminal_record"):
            log_message(self.log, "Flagged customer — opening compliance review panel...", "warning")
            dlg = ComplianceReviewDialog(
                self,
                customer_name=self.current_manual.get("name", "Unknown"),
                criminal_record=cr,
                trust_score=r["trust_score"]
            )
            if dlg.exec_() == QDialog.Accepted:
                cd = dlg.result_data
                self.last_compliance = cd
                self._save_compliance_decision(self.current_manual, cd, r)
                self._show_compliance_report_in_log(cd, r)
                QMessageBox.information(
                    self,
                    "✔  Compliance Report Submitted",
                    f"Action:   {cd['action_full']}\n"
                    f"Officer:  {cd['officer_name']}\n"
                    f"Time:     {cd['timestamp'][:19].replace('T', '  ')}\n\n"
                    f"Report saved. Click 'Export PDF' to generate a printable report."
                )
            else:
                log_message(self.log, "Compliance review cancelled.", "warning")

        self._show_verification_summary_in_log(r)

        # Show export + DIP buttons & refresh live panels
        self.export_btn.setVisible(True)
        self.dip_btn.setVisible(True)
        self._update_dashboard()
        self._refresh_recent_verifications()

    def _show_compliance_report_in_log(self, cd: dict, r: dict):
        """Display a rich, visible compliance report block in the activity log."""
        ts = cd["timestamp"][:19].replace("T", " ")
        notes_text = cd.get("notes", "").strip() or "<i style='color:#718096;'>No notes entered.</i>"
        cr = r.get("criminal_record", {})
        crimes_html = ""
        for crime in cr.get("crimes", []):
            status_color = "#fc8181" if crime.get("status") == "convicted" else "#f6ad55"
            crimes_html += (
                f"<div style='margin:6px 0; padding:8px; background:#0d1117;"
                f" border-left:3px solid #9e6a03; border-radius:4px;'>"
                f"<b style='color:#f85149;'>{crime.get('type','')}</b>"
                f"<span style='color:#8b949e;'> ({crime.get('date','')})</span><br>"
                f"<span style='color:#c9d1d9; font-size:11px;'>{crime.get('description','')}</span><br>"
                f"<span style='color:{status_color}; font-size:11px;'>"
                f"Status: {crime.get('status','').upper()}</span>"
                f"<span style='color:#8b949e; font-size:11px;'>"
                f"  |  Penalty: {crime.get('penalty','N/A')}</span>"
                f"</div>"
            )

        action_color = "#f85149" if "REJECT" in cd["action"] else "#e3b341"
        html = f"""
<div style='margin:10px 0; padding:14px; background:#161b22;
    border:1px solid #da3633; border-radius:6px;'>
  <div style='color:#f85149; font-size:13px; font-weight:600; margin-bottom:8px;'>
    COMPLIANCE REPORT SUBMITTED
  </div>
  <table style='width:100%; color:#e6edf3; font-size:12px;'>
    <tr>
      <td style='color:#8b949e; width:120px;'>Officer</td>
      <td><b style='color:#3fb950;'>{cd['officer_name']}</b></td>
    </tr>
    <tr>
      <td style='color:#8b949e;'>Action Taken</td>
      <td><b style='color:{action_color};'>{cd['action_full']}</b></td>
    </tr>
    <tr>
      <td style='color:#8b949e;'>Timestamp</td>
      <td style='color:#8b949e;'>{ts}</td>
    </tr>
    <tr>
      <td style='color:#8b949e; vertical-align:top; padding-top:4px;'>Notes</td>
      <td style='color:#e6edf3; padding-top:4px;'>{notes_text}</td>
    </tr>
  </table>
  <div style='margin-top:10px; color:#e3b341; font-size:12px; font-weight:600;'>
    Crimes on Record:
  </div>
  {crimes_html}
</div>
"""
        self.log.append(html)
        scrollbar = self.log.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def _show_verification_summary_in_log(self, r: dict):
        """Append a clean verification summary block to the log."""
        trust = r["trust_score"]
        t_color = "#10b981" if trust >= 70 else ("#f59e0b" if trust >= 40 else "#ef4444")
        person_text = "✔  Identity Verified" if r.get("is_correct_person") else "✗  Identity Mismatch"
        person_color = "#10b981" if r.get("is_correct_person") else "#ef4444"
        cr = r.get("criminal_record", {})
        crim_text = "CLEAR" if not cr.get("has_criminal_record") else "FLAGGED"
        crim_color = "#10b981" if not cr.get("has_criminal_record") else "#ef4444"
        flags = r.get("flags", [])
        flags_html = "".join(
            f"<span style='background:#1f3c6e; color:#388bfd; border-radius:3px;"
            f" padding:2px 7px; margin:2px; font-size:11px;'>{f}</span>"
            for f in flags
        ) if flags else "<span style='color:#484f58;'>No flags raised.</span>"

        html = f"""
<div style='margin:10px 0; padding:14px; background:#161b22;
    border:1px solid #21262d; border-radius:6px;'>
  <div style='color:#388bfd; font-size:13px; font-weight:600; margin-bottom:8px;'>
    VERIFICATION COMPLETE
  </div>
  <table style='width:100%; color:#e6edf3; font-size:12px;'>
    <tr>
      <td style='color:#8b949e; width:160px;'>Trust Score</td>
      <td><b style='color:{t_color}; font-size:15px;'>{trust}/100</b>
          <span style='color:{t_color};'> — {r["risk_level"].upper()} RISK</span></td>
    </tr>
    <tr>
      <td style='color:#8b949e;'>Biometric Score</td>
      <td style='color:#e6edf3;'>{r.get("face_score", 0)}%</td>
    </tr>
    <tr>
      <td style='color:#8b949e;'>Document Score</td>
      <td style='color:#e6edf3;'>{r.get("doc_score", 0)}%</td>
    </tr>
    <tr>
      <td style='color:#8b949e;'>Identity Check</td>
      <td><b style='color:{person_color};'>{person_text}</b></td>
    </tr>
    <tr>
      <td style='color:#8b949e;'>Criminal Record</td>
      <td><b style='color:{crim_color};'>{crim_text}</b></td>
    </tr>
  </table>
  <div style='margin-top:8px;'>
    <span style='color:#94a3b8; font-size:12px;'>Flags: </span>
    {flags_html}
  </div>
</div>
"""
        self.log.append(html)
        scrollbar = self.log.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())


def run_demo():
    """Headless console demo — runs simplified verification using demo database."""
    print("CipherPass — Headless Demo Mode\n")
    demo_cnic = "42101-1234567-1"
    manual = {"cnic": demo_cnic, "name": OFFICIAL_DATABASE.get(demo_cnic, {}).get("name", demo_cnic)}

    face_img = np.full((240, 240, 3), 200, dtype=np.uint8)
    cv2.circle(face_img, (120, 90), 40, (0, 0, 0), 3)
    doc_img = np.full((320, 240, 3), 255, dtype=np.uint8)
    cv2.putText(doc_img, demo_cnic, (8, 160), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)

    try:
        fr = run_face_verification(face_img)
    except Exception:
        fr = {"confidence": 0.8, "liveness_score": 0.7}
    face_score = fr.get("confidence", 0.8)

    try:
        doc = analyze_document(doc_img)
    except Exception:
        doc = {"authenticity_score": 0.85}
    doc_score = doc.get("authenticity_score", 0.85)

    profile = get_customer_profile(demo_cnic)
    trust = calculate_trust_score(face_score, doc_score, 0.75)
    if profile["criminal_record"].get("has_criminal_record"):
        trust = max(0, trust - 40)
    if profile["decision"]["status"] == "REJECT":
        trust = max(0, trust - 25)

    bank = bank_record_for_cnic(demo_cnic)
    entered_name = manual.get("name", "")
    is_correct = True
    if bank and entered_name:
        from difflib import SequenceMatcher
        sim = SequenceMatcher(None, entered_name.lower(), bank.get("name", "").lower()).ratio()
        is_correct = sim >= 0.45
        if not is_correct:
            trust = max(0, trust - 35)

    results = {
        "cnic": demo_cnic,
        "entered_name": entered_name,
        "face_score": int(face_score * 100),
        "doc_score": int(doc_score * 100),
        "trust_score": int(trust),
        "risk_level": get_risk_level(trust)[0],
        "is_correct_person": is_correct,
        "criminal_record": profile.get("criminal_record", {}),
        "flags": generate_flags(face_score, doc_score, 0.75),
    }

    print(json.dumps(results, indent=2, ensure_ascii=False))


def main():
    app = QApplication(sys.argv)
    win = KYCApplication()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CipherPass — Encrypted Identity & Fraud Intelligence")
    parser.add_argument("--demo", action="store_true", help="Run headless console demo (no GUI)")
    args = parser.parse_args()
    if args.demo:
        run_demo()
    else:
        main()
